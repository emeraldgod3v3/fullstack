import asyncio
from commands.parser import SlashParser
from tools.registry import ToolRegistry
from core.permissions import PermissionManager
from core.action_engine import ActionEngine

SYSTEM_PROMPT = """You are Roger, a happy wolf CLI AI agent. Answer clearly and directly."""

class RogerAgent:
    def __init__(self, provider, ui):
        self.provider = provider
        self.ui = ui
        self.parser = SlashParser()
        self.tools = ToolRegistry()
        self.permissions = PermissionManager()
        self.action_engine = ActionEngine()
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    async def run(self, prompt):
        cmd = self.parser.parse(prompt)
        if cmd:
            self.ui.assistant(self.handle_command(cmd))
            return

        self.messages.append({"role": "user", "content": prompt})
        actions = self.action_engine.plan(prompt)

        if actions:
            await self._run_actions(actions)
            return

        self.ui.thinking()
        try:
            response = await asyncio.wait_for(
                self.provider.chat(self.messages, self.ui.stream_token, stream=True),
                timeout=self.provider.timeout + 5
            )
        except asyncio.TimeoutError:
            self.ui.error("Provider timeout", "The model took too long. Try again or switch to a faster model.")
            return

        self.messages.append({"role": "assistant", "content": response})
        self.ui.assistant(response, already_streamed=True)

    async def _run_actions(self, actions):
        for action in actions:
            name = action["name"]
            args = action["arguments"]

            if not await self._approve(name, args):
                self.ui.assistant(f"Tool request denied: {name}. Request ended.")
                return

            self.ui.tool_run(name, args)
            result = await self.tools.run(name, args)
            self.ui.tool_result(result)

        names = [a["name"] for a in actions]
        if "create_folder" in names and "write_file" in names:
            final = "Done. I created the folder and file inside the workspace."
        elif "write_file" in names:
            final = "Done. I created the file inside the workspace."
        elif "create_folder" in names:
            final = "Done. I created the folder inside the workspace."
        else:
            final = "Done. The requested action finished."
        self.messages.append({"role": "assistant", "content": final})
        self.ui.assistant(final)

    async def _approve(self, name, args):
        if self.permissions.is_always_allowed(name):
            return True
        choice = self.ui.ask_tool_permission(name, args)
        if choice == "always":
            self.permissions.allow_always(name)
            return True
        return choice == "once"

    def handle_command(self, command):
        c = command["command"]
        if c == "/help":
            return "/help\n/about\n/provider\n/model\n/tools\n/permissions\n/clear\n/exit"
        if c == "/about":
            return "Roger uses a local Claude-Code-style action engine for instant tool prompts."
        if c == "/provider":
            return f"Provider: {self.provider.name}"
        if c == "/model":
            return f"Model: {self.provider.model}"
        if c == "/tools":
            return "\n".join(self.tools.list_tools())
        if c == "/permissions":
            allowed = self.permissions.list_allowed()
            return "\n".join(allowed) if allowed else "No tools are always allowed."
        if c == "/clear":
            self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            return "Chat memory cleared."
        return f"Unknown command: {c}"

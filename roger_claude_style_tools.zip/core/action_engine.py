import re

class ActionEngine:
    def plan(self, prompt):
        text = prompt.strip()
        lower = text.lower()
        actions = []

        if self._is_shell(text):
            return [{"name": "terminal", "arguments": {"command": text}}]

        folder = self._folder(text)
        file_info = self._file(text)

        if folder:
            actions.append({"name": "create_folder", "arguments": {"path": folder}})

        if file_info:
            path = file_info["path"]
            if folder and "/" not in path:
                path = folder + "/" + path
            actions.append({"name": "write_file", "arguments": {"path": path, "content": file_info["content"]}})

        if actions:
            return actions

        if any(x in lower for x in ["list files", "show files", "list folder", "what files"]):
            return [{"name": "list_dir", "arguments": {"path": "."}}]

        return []

    def _is_shell(self, text):
        parts = text.split()
        return bool(parts and parts[0] in {"ls","pwd","echo","cat","python","python3","pip","pip3","git","mkdir","touch","find"})

    def _folder(self, text):
        lower = text.lower()
        if "temp folder" in lower:
            return "temp"
        m = re.search(r'(?:create|make|build|generate)\s+(?:a\s+)?(?:new\s+)?(?:folder|directory)\s+(?:named|called\s+)?["\']?([A-Za-z0-9_./ -]+?)["\']?(?:\s+with|\s+and|\s+inside|\s+containing|$)', text, re.I)
        if m:
            return m.group(1).strip().strip('"\\'').replace(" ", "_")
        m = re.search(r'(?:create|make|build|generate)\s+["\']?([A-Za-z0-9_./ -]+?)["\']?\s+(?:folder|directory)', text, re.I)
        if m:
            return m.group(1).strip().strip('"\\'').replace(" ", "_")
        return None

    def _file(self, text):
        lower = text.lower()
        if "file" not in lower and ".txt" not in lower and ".py" not in lower:
            return None
        return {"path": self._filename(text) or "hello.txt", "content": self._content(text)}

    def _filename(self, text):
        m = re.search(r'["\']([^"\']+\.[A-Za-z0-9]+)["\']', text)
        if m:
            return m.group(1).strip()
        m = re.search(r'([A-Za-z0-9_./-]+\.[A-Za-z0-9]+)', text)
        if m:
            return m.group(1).strip()
        if "python file" in text.lower():
            return "main.py"
        return "hello.txt"

    def _content(self, text):
        for pat in [
            r'(?:says|say|containing|contains|content|with text|text content)\s+["\']([^"\']+)["\']',
            r'(?:write|put)\s+["\']([^"\']+)["\']'
        ]:
            m = re.search(pat, text, re.I)
            if m:
                return m.group(1)
        if "hello world" in text.lower():
            return "hello world!"
        return ""

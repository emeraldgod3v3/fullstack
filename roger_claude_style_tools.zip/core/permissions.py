import json, os
from pathlib import Path

class PermissionManager:
    def __init__(self):
        self.path = Path(os.getenv("PERMISSIONS_FILE", ".roger_permissions.json"))
        self.data = {"always_allow": []}
        self._load()

    def _load(self):
        if self.path.exists():
            try:
                self.data = json.loads(self.path.read_text())
            except Exception:
                self.data = {"always_allow": []}

    def _save(self):
        self.path.write_text(json.dumps(self.data, indent=2))

    def is_always_allowed(self, name):
        return name in self.data.get("always_allow", [])

    def allow_always(self, name):
        if name not in self.data["always_allow"]:
            self.data["always_allow"].append(name)
            self._save()

    def list_allowed(self):
        return self.data.get("always_allow", [])

import asyncio, json, os, httpx
from dotenv import load_dotenv
load_dotenv()

class NvidiaProvider:
    name = "nvidia"
    def __init__(self, model, timeout=45, max_retries=1, streaming=True):
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self.streaming = streaming
        self.base_url = os.getenv("NVIDIA_BASE_URL", "https://integrate.api.nvidia.com/v1/chat/completions")
        self.api_key = os.getenv("NVIDIA_API_KEY", "").strip()
        if not self.api_key:
            raise ValueError("NVIDIA_API_KEY is missing. Add it inside .env.")

    async def chat(self, messages, on_token=None, stream=None):
        use_stream = self.streaming if stream is None else stream
        payload = {"model": self.model, "messages": messages, "temperature": 0.3, "max_tokens": 512, "stream": use_stream}
        if use_stream:
            return await self._stream(payload, on_token)
        return await self._normal(payload)

    async def _normal(self, payload):
        async with httpx.AsyncClient(timeout=self._timeout()) as client:
            r = await client.post(self.base_url, headers=self._headers(), json=payload)
        if r.status_code >= 400:
            return self._err(r.status_code, r.text)
        return r.json()["choices"][0]["message"]["content"]

    async def _stream(self, payload, on_token):
        full = ""
        try:
            async with httpx.AsyncClient(timeout=self._timeout()) as client:
                async with client.stream("POST", self.base_url, headers=self._headers(), json=payload) as r:
                    if r.status_code >= 400:
                        body = await r.aread()
                        return self._err(r.status_code, body.decode(errors="ignore"))
                    async for line in r.aiter_lines():
                        if not line:
                            continue
                        if line.startswith("data: "):
                            line = line[6:]
                        if line.strip() == "[DONE]":
                            break
                        try:
                            data = json.loads(line)
                            token = data["choices"][0].get("delta", {}).get("content", "")
                            if token:
                                full += token
                                if on_token:
                                    on_token(token)
                        except Exception:
                            pass
            return full or "No response received."
        except (httpx.ReadTimeout, httpx.ConnectTimeout):
            return "Provider timeout. Try again or switch to a faster model."
        except httpx.RequestError as e:
            return f"Network error: {e}"

    def _headers(self):
        return {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json", "Accept": "application/json"}

    def _timeout(self):
        return httpx.Timeout(connect=10.0, read=self.timeout, write=10.0, pool=10.0)

    def _err(self, status, body):
        if status == 401:
            return "NVIDIA API error 401. Check your NVIDIA_API_KEY."
        if status == 404:
            return f"NVIDIA API error 404. Check model name: {self.model}"
        if status == 429:
            return "NVIDIA API error 429. Rate limit reached."
        return f"NVIDIA API error {status}: {body[:300]}"

# Roger Claude-Style Tools Edition

This fixes the slow response issue for file and terminal actions.

Roger now uses a local action engine. It does not ask the model before tool use.

Flow:

```txt
User asks action -> local action engine -> permission prompt -> tool runs -> done
```

Setup:

```bash
unzip roger_claude_style_tools.zip
cd roger_claude_style_tools
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
python3 main.py
```

Add:

```env
NVIDIA_API_KEY=your_key_here
```

Test:

```txt
create a temp folder with a text file that says "hello world!"
```

Expected:

- Permission prompt appears fast
- File is created in `workspace/temp/hello.txt`

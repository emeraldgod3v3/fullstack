# Roger Agent Fast Tools Edition

This build fixes the 4-minute hang before tool permissions.

## What changed

Roger no longer asks the AI model whether a tool is needed.

Instead, it uses a fast local planner:

```txt
User request -> Local tool planner -> Permission menu -> Tool runs -> AI final response
```

This makes the permission prompt show instantly.

## Fixed

- No 4-minute wait before tool permission
- No model call for simple tool detection
- Future tools can be added in `core/planner.py`
- Arrow-key permission menu
- Clean terminal launch
- Streaming answers
- GLM-4.7 default
- Workspace-safe file operations

## Setup

```bash
unzip roger_agent_fast_tools.zip
cd roger_agent_fast_tools
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Add:

```env
NVIDIA_API_KEY=your_key_here
```

Run:

```bash
python3 main.py
```

## Test tool calling

Ask:

```txt
Try to create a temp folder with a text file that says "hello world!" inside of it.
```

Roger should show the permission prompt instantly.

## Workspace

All file actions happen inside:

```txt
workspace/
```

## Add more tools later

Add tool logic in:

```txt
tools/
core/planner.py
tools/registry.py
```

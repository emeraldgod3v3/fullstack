from commands.parser import SlashParser
from tools.registry import ToolRegistry
from core.permissions import PermissionManager
from core.planner import LocalToolPlanner

SYSTEM_PROMPT = """
You are Roger, a happy wolf CLI AI agent.
You answer clearly and directly.
You help with coding, Linux, files, debugging, planning, and project work.
"""

class RogerAgent:
    def __init__(self, provider, ui):
        self.provider = provider
        self.ui = ui
        self.parser = SlashParser()
        self.tools = ToolRegistry()
        self.permissions = PermissionManager()
        self.planner = LocalToolPlanner()
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    async def run(self, prompt):
        command = self.parser.parse(prompt)

        if command:
            self.ui.assistant(self.handle_command(command))
            return

        self.messages.append({"role": "user", "content": prompt})

        tool_calls = self.planner.plan(prompt)

        if tool_calls:
            await self._handle_tool_flow(tool_calls)
            return

        self.ui.thinking()
        response = await self.provider.chat(self.messages, self.ui.stream_token, stream=True)
        self.messages.append({"role": "assistant", "content": response})
        self.ui.assistant(response, already_streamed=True)

    async def _handle_tool_flow(self, tool_calls):
        results = []

        for call in tool_calls:
            tool_name = call["name"]
            tool_args = call["arguments"]

            allowed = await self._approve_tool(tool_name, tool_args)

            if not allowed:
                denied = f"Tool request denied: {tool_name}. Request ended."
                self.messages.append({"role": "assistant", "content": denied})
                self.ui.assistant(denied)
                return

            self.ui.tool_run(tool_name, tool_args)
            result = await self.tools.run(tool_name, tool_args)
            self.ui.tool_result(result)

            results.append(f"{tool_name}: {result}")

        summary = "\n".join(results)

        final_prompt = (
            "The requested tool actions are complete. "
            "Give the user a short confirmation. "
            "Do not mention JSON. "
            f"Tool results:\n{summary}"
        )

        self.messages.append({"role": "user", "content": final_prompt})

        self.ui.thinking()
        final = await self.provider.chat(self.messages, self.ui.stream_token, stream=True)
        self.messages.append({"role": "assistant", "content": final})
        self.ui.assistant(final, already_streamed=True)

    async def _approve_tool(self, tool_name, tool_args):
        if self.permissions.is_always_allowed(tool_name):
            return True

        choice = self.ui.ask_tool_permission(tool_name, tool_args)

        if choice == "always":
            self.permissions.allow_always(tool_name)
            return True

        if choice == "once":
            return True

        return False

    def handle_command(self, command):
        cmd = command["command"]

        if cmd == "/help":
            return """
Commands:

/help          Show commands
/about         Show Roger info
/provider      Show active provider
/model         Show active model
/tools         Show registered tools
/permissions   Show always-allowed tools
/clear         Clear chat memory
/exit          Exit Roger
"""

        if cmd == "/about":
            return """
Roger is a happy wolf CLI AI agent.

Features:
- Instant local tool planner
- No AI wait before tool permission prompt
- Arrow-key approval menu
- Streaming text responses
- NVIDIA GLM-4.7 default
- Responsive TUI
- Workspace-safe file operations
- Safe terminal execution
- Clean terminal launch
"""

        if cmd == "/provider":
            return f"Provider: {self.provider.name}"

        if cmd == "/model":
            return f"Model: {self.provider.model}"

        if cmd == "/tools":
            return "\n".join(self.tools.list_tools())

        if cmd == "/permissions":
            allowed = self.permissions.list_allowed()
            return "\n".join(allowed) if allowed else "No tools are always allowed."

        if cmd == "/clear":
            self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            return "Chat memory cleared."

        return f"Unknown command: {cmd}"

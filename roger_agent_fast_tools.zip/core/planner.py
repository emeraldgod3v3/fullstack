import re
import shlex

class LocalToolPlanner:
    """
    Fast deterministic planner.
    It avoids asking the model whether a tool is needed.
    Add future tools here without slowing the permission prompt.
    """

    def plan(self, prompt):
        text = prompt.strip()
        lower = text.lower()

        if self._looks_like_terminal_command(text):
            return [
                {
                    "name": "terminal",
                    "arguments": {
                        "command": text
                    }
                }
            ]

        folder = self._extract_folder_name(text)
        file_data = self._extract_file_request(text)

        calls = []

        if folder:
            calls.append({
                "name": "create_folder",
                "arguments": {
                    "path": folder
                }
            })

        if file_data:
            path = file_data["path"]

            if folder and "/" not in path:
                path = f"{folder}/{path}"

            calls.append({
                "name": "write_file",
                "arguments": {
                    "path": path,
                    "content": file_data["content"]
                }
            })

        if calls:
            return calls

        if any(word in lower for word in ["list files", "show files", "list folder", "show folder"]):
            folder = self._extract_after_keywords(lower, ["inside", "in", "from"]) or "."
            return [
                {
                    "name": "list_dir",
                    "arguments": {
                        "path": folder
                    }
                }
            ]

        if any(word in lower for word in ["read file", "open file", "show file"]):
            file_name = self._extract_filename(text) or "README.md"
            return [
                {
                    "name": "read_file",
                    "arguments": {
                        "path": file_name
                    }
                }
            ]

        return []

    def _looks_like_terminal_command(self, text):
        first = text.split()[0] if text.split() else ""
        return first in [
            "ls", "pwd", "echo", "cat", "python", "python3",
            "pip", "pip3", "git", "mkdir", "touch", "find"
        ]

    def _extract_folder_name(self, text):
        patterns = [
            r"(?:create|make|build|generate)\\s+(?:a\\s+)?(?:new\\s+)?(?:folder|directory)\\s+(?:named|called)?\\s*[\"']?([\\w\\-.\\/ ]+?)[\"']?(?:\\s+with|\\s+and|\\s+inside|\\s+containing|$)",
            r"(?:create|make|build|generate)\\s+([\\w\\-.\\/]+)\\s+(?:folder|directory)",
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                folder = match.group(1).strip().strip("\"'")
                folder = folder.replace(" ", "_")
                return folder

        if "temp folder" in text.lower():
            return "temp"

        return None

    def _extract_file_request(self, text):
        lower = text.lower()

        if not any(word in lower for word in ["file", ".txt", "text file"]):
            return None

        filename = self._extract_filename(text)
        content = self._extract_content(text)

        if not filename:
            filename = "hello.txt"

        return {
            "path": filename,
            "content": content
        }

    def _extract_filename(self, text):
        quoted = re.findall(r"[\"']([^\"']+\\.[\\w]+)[\"']", text)
        if quoted:
            return quoted[0].strip()

        direct = re.search(r"([\\w\\-.\\/]+\\.[a-zA-Z0-9]+)", text)
        if direct:
            return direct.group(1).strip()

        if "text file" in text.lower():
            return "hello.txt"

        return None

    def _extract_content(self, text):
        patterns = [
            r"(?:says|containing|contains|content|with text|text content)\\s+[\"']([^\"']+)[\"']",
            r"(?:write|put)\\s+[\"']([^\"']+)[\"']",
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1)

        if "hello world" in text.lower():
            return "hello world!"

        return ""

    def _extract_after_keywords(self, text, keywords):
        for keyword in keywords:
            pattern = rf"{keyword}\\s+([\\w\\-.\\/]+)"
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        return None

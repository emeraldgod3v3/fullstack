from tools.terminal import terminal_tool
from tools.filesystem import create_folder, read_file, write_file, append_file, list_dir

class ToolRegistry:
    def __init__(self):
        self.tools = {
            "terminal": terminal_tool,
            "create_folder": create_folder,
            "read_file": read_file,
            "write_file": write_file,
            "append_file": append_file,
            "list_dir": list_dir,
        }

    def list_tools(self):
        return list(self.tools.keys())

    async def run(self, name, arguments):
        if name not in self.tools:
            return f"Unknown tool: {name}"

        try:
            return await self.tools[name](**arguments)
        except TypeError as error:
            return f"Tool argument error: {error}"
        except Exception as error:
            return f"Tool failed: {error}"

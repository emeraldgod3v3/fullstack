import os
from pathlib import Path

WORKSPACE = Path(os.getenv("WORKSPACE_DIR", "workspace")).resolve()
WORKSPACE.mkdir(parents=True, exist_ok=True)

def safe_path(path):
    target = (WORKSPACE / path).resolve()

    if not str(target).startswith(str(WORKSPACE)):
        raise ValueError("Path blocked. Use paths inside the workspace only.")

    return target

async def create_folder(path):
    target = safe_path(path)
    target.mkdir(parents=True, exist_ok=True)
    return f"Created folder: {target}"

async def read_file(path):
    target = safe_path(path)

    if not target.exists():
        return f"File not found: {target}"

    return target.read_text(encoding="utf-8")

async def write_file(path, content):
    target = safe_path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return f"Wrote file: {target}"

async def append_file(path, content):
    target = safe_path(path)
    target.parent.mkdir(parents=True, exist_ok=True)

    with target.open("a", encoding="utf-8") as file:
        file.write(content)

    return f"Appended file: {target}"

async def list_dir(path="."):
    target = safe_path(path)

    if not target.exists():
        return f"Folder not found: {target}"

    items = []
    for item in target.iterdir():
        kind = "folder" if item.is_dir() else "file"
        items.append(f"{kind}: {item.name}")

    return "\n".join(items) if items else "Folder is empty."

import asyncio
import os
from pathlib import Path

WORKSPACE = Path(os.getenv("WORKSPACE_DIR", "workspace")).resolve()
WORKSPACE.mkdir(parents=True, exist_ok=True)

SAFE_COMMANDS = [
    "ls", "pwd", "echo", "cat", "python", "python3",
    "pip", "pip3", "git", "mkdir", "touch", "find"
]

BLOCKED_PATTERNS = [
    "rm -rf /", ":(){", "mkfs", "shutdown", "reboot",
    "dd if=", "chmod -R 777 /", "sudo"
]

async def terminal_tool(command):
    command = command.strip()

    if not command:
        return "No command provided."

    base = command.split()[0]

    if base not in SAFE_COMMANDS:
        return f"Blocked command: {base}"

    for pattern in BLOCKED_PATTERNS:
        if pattern in command:
            return f"Blocked dangerous pattern: {pattern}"

    process = await asyncio.create_subprocess_shell(
        command,
        cwd=str(WORKSPACE),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )

    try:
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=60)
    except asyncio.TimeoutError:
        process.kill()
        return "Command timed out after 60 seconds."

    out = stdout.decode(errors="ignore").strip()
    err = stderr.decode(errors="ignore").strip()

    if err:
        return err

    return out if out else "Command completed."

import json
from rich.console import Console
from rich.panel import Panel
from rich.align import Align
from rich.text import Text
from rich.table import Table
from rich.markdown import Markdown
from rich.live import Live
from rich import box
from prompt_toolkit.shortcuts import radiolist_dialog

WOLF_DESKTOP = """
        /\\_/\\\\
       ( ^ᴥ^ )
      /|  🐺  |\\\\
     /_|_____|_\\\\

        ROGER
"""

WOLF_MOBILE = """
 /\\_/\\\\
( ^ᴥ^ )
  🐺
ROGER
"""

class RogerUI:
    def __init__(self):
        self.console = Console()
        self.live = None
        self.stream_buffer = ""

    def is_mobile(self):
        return self.console.width < 75

    def clean_text(self, text):
        return str(text).replace("\\n", "\n")

    def show_intro(self):
        logo = WOLF_MOBILE if self.is_mobile() else WOLF_DESKTOP

        title = Text()
        title.append(logo, style="bold cyan")
        title.append("\nHappy Wolf AI Agent", style="bold green")

        self.console.print(
            Panel(
                Align.center(title),
                title="[bold cyan]Roger[/bold cyan]",
                subtitle="Fast tool calling CLI agent",
                border_style="cyan",
                box=box.ROUNDED if self.is_mobile() else box.DOUBLE
            )
        )

        self.show_commands()

    def show_commands(self):
        table = Table(
            title="Quick Commands",
            box=box.SIMPLE if self.is_mobile() else box.ROUNDED,
            border_style="green",
            show_lines=not self.is_mobile()
        )

        table.add_column("Command", style="cyan", no_wrap=True)
        table.add_column("Action", style="white")

        rows = [
            ("/help", "Commands"),
            ("/provider", "Provider"),
            ("/model", "Model"),
            ("/tools", "Tools"),
            ("/permissions", "Allowed tools"),
            ("/clear", "Clear memory"),
            ("/exit", "Quit"),
        ]

        for command, action in rows:
            table.add_row(command, action)

        self.console.print(table)

    def show_ready(self, provider):
        self.console.print(
            Panel(
                f"[green]Provider:[/green] {provider.name}\n"
                f"[green]Model:[/green] {provider.model}\n"
                f"[green]Status:[/green] Ready",
                title="Session",
                border_style="green",
                box=box.ROUNDED
            )
        )

    def thinking(self):
        self.stream_buffer = ""
        self.stop_live()
        self.console.print("[dim cyan]Roger is thinking...[/dim cyan]")

    def stream_token(self, token):
        self.stream_buffer += token
        panel = Panel(
            Markdown(self.clean_text(self.stream_buffer)),
            title="[bold cyan]Roger 🐺 streaming[/bold cyan]",
            border_style="cyan",
            box=box.ROUNDED
        )

        if self.live is None:
            self.live = Live(panel, console=self.console, refresh_per_second=10, transient=False)
            self.live.start()
        else:
            self.live.update(panel)

    def stop_live(self):
        if self.live is not None:
            self.live.stop()
            self.live = None

    def assistant(self, text, already_streamed=False):
        if self.live is not None:
            self.stop_live()
            if already_streamed:
                return

        self.console.print(
            Panel(
                Markdown(self.clean_text(text)),
                title="[bold cyan]Roger 🐺[/bold cyan]",
                border_style="cyan",
                box=box.ROUNDED
            )
        )

    def ask_tool_permission(self, tool_name, tool_args):
        self.stop_live()

        args = json.dumps(tool_args, indent=2)

        message = (
            f"Roger wants to run this tool:\n\n"
            f"Tool: {tool_name}\n\n"
            f"Arguments:\n{args}\n\n"
            "Use ↑ and ↓ to select. Press Enter to confirm."
        )

        try:
            result = radiolist_dialog(
                title="Roger Tool Permission",
                text=message,
                values=[
                    ("always", f"Always allow {tool_name}"),
                    ("once", f"Allow {tool_name} once"),
                    ("deny", "Don't approve"),
                ],
            ).run()

            return result or "deny"

        except Exception:
            self.console.print(
                Panel(
                    f"[bold]Tool requested:[/bold] {tool_name}\n\n"
                    f"[bold]Arguments:[/bold]\n{args}\n\n"
                    "Type one option:\n"
                    "always  - Always allow this tool\n"
                    "once    - Allow once\n"
                    "deny    - Don't approve",
                    title="[yellow]Tool Permission[/yellow]",
                    border_style="yellow",
                    box=box.ROUNDED
                )
            )

            while True:
                choice = self.console.input("[yellow]Choice: [/yellow]").strip().lower()
                if choice in ["always", "once", "deny"]:
                    return choice
                self.console.print("[red]Invalid choice. Use always, once, or deny.[/red]")

    def tool_run(self, name, args):
        self.console.print(
            Panel(
                json.dumps(args, indent=2),
                title=f"[magenta]Running tool: {name}[/magenta]",
                border_style="magenta",
                box=box.ROUNDED
            )
        )

    def tool_result(self, result):
        self.console.print(
            Panel(
                self.clean_text(result),
                title="[green]Tool Result[/green]",
                border_style="green",
                box=box.ROUNDED
            )
        )

    def warning(self, title, text):
        self.console.print(Panel(self.clean_text(text), title=title, border_style="yellow"))

    def error(self, title, text):
        self.console.print(Panel(self.clean_text(text), title=f"[bold red]{title}[/bold red]", border_style="red"))

    def goodbye(self):
        self.stop_live()
        self.console.print("[bold cyan]Roger closed. Goodbye.[/bold cyan]")

# ROGER 2026.5.9

## New in this build

- Removed wolf emoji branding
- Added solid `R O G E R` title
- Added version `2026.5.9`
- Added bordered user prompt field
- Added `ROGER.md`
- Added `WOLF.md`
- Added `/memory`
- Added memory detection
- Improved shell command intent handling
- Better directory question handling

## Copy-paste install command

```bash
rm -rf roger && unzip roger_2026_5_9.zip -d roger && cd roger && python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt && cp .env.example .env && nano .env && python3 main.py
```

Add your API key:

```env
NVIDIA_API_KEY=your_key_here
```

## Test memory

```txt
i like coffee
```

Roger stores this in:

```txt
WOLF.md
```

## Test shell command intent

```txt
whats outside of my directory?
```

Roger should request permission to run:

```bash
find . -maxdepth 2 -type f -o -type d
```

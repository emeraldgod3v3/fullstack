import asyncio
import os
from dotenv import load_dotenv
from prompt_toolkit import PromptSession
from prompt_toolkit.styles import Style

from core.agent import RogerAgent
from core.provider_loader import load_provider
from tui.ui import RogerUI

load_dotenv()

def clear_terminal():
    if os.getenv("CLEAR_ON_START", "true").lower() == "true":
        os.system("cls" if os.name == "nt" else "clear")

async def main():
    clear_terminal()

    ui = RogerUI()
    ui.show_intro()

    try:
        provider = load_provider()
    except Exception as error:
        ui.error("Startup failed", str(error))
        return

    agent = RogerAgent(provider, ui)
    session = PromptSession(
        style=Style.from_dict({
            "prompt": "ansicyan bold"
        })
    )

    ui.show_ready(provider)

    while True:
        try:
            ui.prompt_box()
            text = (
                await session.prompt_async(
                    [("class:prompt", " ROGER > ")]
                )
            ).strip()

            if not text:
                continue

            if text == "/exit":
                ui.goodbye()
                break

            await agent.run(text)

        except KeyboardInterrupt:
            ui.warning("Input cancelled", "Press /exit to close Roger.")
        except EOFError:
            ui.goodbye()
            break
        except Exception as error:
            ui.error("Unexpected error", str(error))

if __name__ == "__main__":
    asyncio.run(main())

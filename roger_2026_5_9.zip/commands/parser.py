class SlashParser:
    def parse(self, text):
        if not text.startswith("/"):
            return None

        parts = text.split()

        return {
            "command": parts[0],
            "args": parts[1:]
        }

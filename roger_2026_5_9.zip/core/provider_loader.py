import os

from providers.nvidia_provider import NvidiaProvider
from providers.openai_provider import OpenAIProvider
from providers.anthropic_provider import AnthropicProvider

def load_provider():
    provider = os.getenv("DEFAULT_PROVIDER", "nvidia").lower().strip()
    timeout = float(os.getenv("REQUEST_TIMEOUT", "45"))
    retries = int(os.getenv("MAX_RETRIES", "1"))
    streaming = os.getenv("STREAMING", "true").lower() == "true"

    if provider == "openai":
        return OpenAIProvider(
            os.getenv("OPENAI_MODEL", "gpt-4.1"),
            timeout,
            retries,
            streaming
        )

    if provider == "anthropic":
        return AnthropicProvider(
            os.getenv("ANTHROPIC_MODEL", "claude-3-7-sonnet-latest"),
            timeout,
            retries,
            streaming
        )

    return NvidiaProvider(
        os.getenv("NVIDIA_MODEL", "z-ai/glm4.7"),
        timeout,
        retries,
        streaming
    )

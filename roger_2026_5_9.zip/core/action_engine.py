import re

class ActionEngine:
    def plan(self, prompt):
        text = prompt.strip()
        lower = text.lower()
        actions = []

        shell = self._shell_from_request(text)

        if shell:
            return [
                {
                    "name": "terminal",
                    "arguments": {
                        "command": shell
                    }
                }
            ]

        folder = self._folder(text)
        file_info = self._file(text)

        if folder:
            actions.append({
                "name": "create_folder",
                "arguments": {
                    "path": folder
                }
            })

        if file_info:
            path = file_info["path"]

            if folder and "/" not in path:
                path = folder + "/" + path

            actions.append({
                "name": "write_file",
                "arguments": {
                    "path": path,
                    "content": file_info["content"]
                }
            })

        if actions:
            return actions

        if any(x in lower for x in [
            "what files",
            "list files",
            "show files",
            "list folder",
            "show folder",
            "what is in this directory",
            "what's in this directory",
            "whats in this directory",
            "what is outside of my directory",
            "what's outside of my directory",
            "whats outside of my directory",
            "show directory",
            "list directory"
        ]):
            return [
                {
                    "name": "terminal",
                    "arguments": {
                        "command": "find . -maxdepth 2 -type f -o -type d"
                    }
                }
            ]

        if any(x in lower for x in ["current directory", "where am i", "pwd"]):
            return [
                {
                    "name": "terminal",
                    "arguments": {
                        "command": "pwd"
                    }
                }
            ]

        if any(x in lower for x in ["read file", "open file", "show file", "cat file"]):
            filename = self._filename(text)
            return [
                {
                    "name": "read_file",
                    "arguments": {
                        "path": filename
                    }
                }
            ]

        return []

    def _shell_from_request(self, text):
        parts = text.split()

        if parts and parts[0] in {
            "ls",
            "pwd",
            "echo",
            "cat",
            "python",
            "python3",
            "pip",
            "pip3",
            "git",
            "mkdir",
            "touch",
            "find",
            "tree",
        }:
            return text

        lower = text.lower()

        command_patterns = [
            r"(?:run|execute|use)\s+(?:the\s+)?(?:command\s+)?[`'\"]([^`'\"]+)[`'\"]",
            r"(?:run|execute)\s+(.+)$",
        ]

        for pattern in command_patterns:
            match = re.search(pattern, text, re.IGNORECASE)

            if match:
                command = match.group(1).strip()

                if command:
                    return command

        if "show hidden files" in lower:
            return "ls -la"

        if "list all files" in lower:
            return "ls -la"

        if "show git status" in lower or "git status" in lower:
            return "git status"

        return None

    def _folder(self, text):
        lower = text.lower()

        if "temp folder" in lower:
            return "temp"

        patterns = [
            r"(?:create|make|build|generate)\s+(?:a\s+)?(?:new\s+)?(?:folder|directory)\s+(?:named|called\s+)?[\"']?([A-Za-z0-9_./ -]+?)[\"']?(?:\s+with|\s+and|\s+inside|\s+containing|$)",
            r"(?:create|make|build|generate)\s+[\"']?([A-Za-z0-9_./ -]+?)[\"']?\s+(?:folder|directory)"
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)

            if match:
                value = match.group(1)
                value = value.strip()
                value = value.strip("\"'")
                value = value.replace(" ", "_")

                if value:
                    return value

        return None

    def _file(self, text):
        lower = text.lower()

        if "file" not in lower and ".txt" not in lower and ".py" not in lower and ".md" not in lower and ".html" not in lower:
            return None

        return {
            "path": self._filename(text),
            "content": self._content(text),
        }

    def _filename(self, text):
        quoted = re.search(r"[\"']([^\"']+\.[A-Za-z0-9]+)[\"']", text)

        if quoted:
            return quoted.group(1).strip()

        direct = re.search(r"([A-Za-z0-9_./-]+\.[A-Za-z0-9]+)", text)

        if direct:
            return direct.group(1).strip()

        lower = text.lower()

        if "html" in lower:
            return "index.html"

        if "python file" in lower:
            return "main.py"

        if "markdown file" in lower:
            return "README.md"

        return "hello.txt"

    def _content(self, text):
        patterns = [
            r"(?:says|say|containing|contains|content|with text|text content)\s+[\"']([^\"']+)[\"']",
            r"(?:write|put)\s+[\"']([^\"']+)[\"']"
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)

            if match:
                return match.group(1)

        lower = text.lower()

        if "hello world" in lower and "html" in lower:
            return "<!DOCTYPE html>\\n<html>\\n<head>\\n  <title>Hello World</title>\\n</head>\\n<body>\\n  <h1>Hello World</h1>\\n</body>\\n</html>"

        if "hello world" in lower:
            return "hello world!"

        return ""

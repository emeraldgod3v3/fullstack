import asyncio
from pathlib import Path

from commands.parser import SlashParser
from tools.registry import ToolRegistry
from core.permissions import PermissionManager
from core.action_engine import ActionEngine
from core.memory import WolfMemory

def load_roger_prompt():
    path = Path("ROGER.md")

    if path.exists():
        return path.read_text(encoding="utf-8")

    return "You are Roger, a CLI AI agent."

class RogerAgent:
    def __init__(self, provider, ui):
        self.provider = provider
        self.ui = ui
        self.parser = SlashParser()
        self.tools = ToolRegistry()
        self.permissions = PermissionManager()
        self.action_engine = ActionEngine()
        self.memory = WolfMemory()
        self.messages = [
            {
                "role": "system",
                "content": load_roger_prompt() + "\n\nUser memory:\n" + self.memory.read()
            }
        ]

    async def run(self, prompt):
        command = self.parser.parse(prompt)

        if command:
            self.ui.assistant(self.handle_command(command))
            return

        memory = self.memory.detect_memory(prompt)

        if memory:
            result = self.memory.remember(memory)
            self.ui.assistant(result)
            self._refresh_system_prompt()
            return

        self.messages.append({"role": "user", "content": prompt})

        actions = self.action_engine.plan(prompt)

        if actions:
            await self._run_actions(actions)
            return

        self.ui.thinking()

        try:
            response = await asyncio.wait_for(
                self.provider.chat(
                    self.messages,
                    self.ui.stream_token,
                    stream=True
                ),
                timeout=self.provider.timeout + 5
            )

        except asyncio.TimeoutError:
            self.ui.error(
                "Provider timeout",
                "The model took too long. Try again or switch to a faster model."
            )
            return

        self.messages.append({"role": "assistant", "content": response})
        self.ui.assistant(response, already_streamed=True)

    async def _run_actions(self, actions):
        for action in actions:
            name = action["name"]
            args = action["arguments"]

            if not await self._approve(name, args):
                self.ui.assistant(f"Tool request denied: {name}. Request ended.")
                return

            self.ui.tool_run(name, args)
            result = await self.tools.run(name, args)
            self.ui.tool_result(result)

        names = [action["name"] for action in actions]

        if "terminal" in names:
            final = "Done. I ran the approved shell command."
        elif "create_folder" in names and "write_file" in names:
            final = "Done. I created the folder and file inside the workspace."
        elif "write_file" in names:
            final = "Done. I created the file inside the workspace."
        elif "create_folder" in names:
            final = "Done. I created the folder inside the workspace."
        else:
            final = "Done. The requested action finished."

        self.messages.append({"role": "assistant", "content": final})
        self.ui.assistant(final)

    async def _approve(self, name, args):
        if self.permissions.is_always_allowed(name):
            return True

        choice = self.ui.ask_tool_permission(name, args)

        if choice == "always":
            self.permissions.allow_always(name)
            return True

        return choice == "once"

    def _refresh_system_prompt(self):
        self.messages[0] = {
            "role": "system",
            "content": load_roger_prompt() + "\n\nUser memory:\n" + self.memory.read()
        }

    def handle_command(self, command):
        cmd = command["command"]

        if cmd == "/help":
            return "/help\n/about\n/provider\n/model\n/tools\n/permissions\n/memory\n/clear\n/exit"

        if cmd == "/about":
            return "ROGER 2026.5.9 uses ROGER.md for role and WOLF.md for memory."

        if cmd == "/provider":
            return f"Provider: {self.provider.name}"

        if cmd == "/model":
            return f"Model: {self.provider.model}"

        if cmd == "/tools":
            return "\n".join(self.tools.list_tools())

        if cmd == "/permissions":
            allowed = self.permissions.list_allowed()
            return "\n".join(allowed) if allowed else "No tools are always allowed."

        if cmd == "/memory":
            return self.memory.read()

        if cmd == "/clear":
            self.messages = [
                {
                    "role": "system",
                    "content": load_roger_prompt() + "\n\nUser memory:\n" + self.memory.read()
                }
            ]
            return "Chat memory cleared."

        return f"Unknown command: {cmd}"

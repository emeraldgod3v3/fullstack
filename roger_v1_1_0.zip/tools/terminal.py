import asyncio
import os
from pathlib import Path

WORKSPACE = Path(os.getenv("WORKSPACE_DIR", "workspace")).resolve()
WORKSPACE.mkdir(parents=True, exist_ok=True)

SAFE = {
    "ls", "pwd", "echo", "cat", "python", "python3",
    "pip", "pip3", "git", "mkdir", "touch", "find", "tree"
}

BLOCKED = [
    "rm -rf /",
    ":(){",
    "mkfs",
    "shutdown",
    "reboot",
    "dd if=",
    "chmod -R 777 /",
    "sudo",
]

async def terminal_tool(command):
    command = command.strip()
    if not command:
        return "No command provided."

    base = command.split()[0]

    if base not in SAFE:
        return f"Blocked command: {base}"

    for pattern in BLOCKED:
        if pattern in command:
            return f"Blocked dangerous pattern: {pattern}"

    process = await asyncio.create_subprocess_shell(
        command,
        cwd=str(WORKSPACE),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    try:
        stdout, stderr = await asyncio.wait_for(
            process.communicate(),
            timeout=60
        )
    except asyncio.TimeoutError:
        process.kill()
        return "Command timed out after 60 seconds."

    err = stderr.decode(errors="ignore").strip()
    out = stdout.decode(errors="ignore").strip()

    return err or out or "Command completed."

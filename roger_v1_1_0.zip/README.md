# ROGER v1.1.0

## What changed

- AI-driven tool calling added
- Roger can return JSON tool calls and execute approved tools
- Better command execution flow
- Better prompt border
- Separate updater: `roger_cli_installation.py`
- Main update command: `python3 main.py --update`
- Manifest-based update system

## Copy-paste install

```bash
rm -rf roger && unzip roger_v1_1_0.zip -d roger && cd roger && python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt && cp .env.example .env && nano .env && python3 main.py
```

Add:

```env
NVIDIA_API_KEY=your_key_here
```

## Update system

You do not need to push the zip to GitHub.

Upload the zip somewhere secure:

- Cloudflare R2 signed URL
- AWS S3 presigned URL
- Google Cloud Storage signed URL
- Backblaze B2 private bucket
- Supabase Storage signed URL

Create a `manifest.json` like this:

```json
{
  "project-version": "1.1.1",
  "zip-url": "https://your-secure-storage.com/roger_v1_1_1.zip",
  "sha256": "optional_sha256_hash"
}
```

Set this in `.env`:

```env
ROGER_UPDATE_MANIFEST_URL=https://your-secure-storage.com/manifest.json
```

Run:

```bash
python3 main.py --update
```

The updater keeps:

- `.env`
- `WOLF.md`
- `.roger_permissions.json`
- `workspace/`
- `venv/`

## Test AI tool calling

Ask:

```txt
run the command "ls -la"
```

or:

```txt
show me the project folder content
```

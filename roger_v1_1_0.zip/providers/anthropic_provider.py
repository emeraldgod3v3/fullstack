import os
from dotenv import load_dotenv
from anthropic import AsyncAnthropic

load_dotenv()

class AnthropicProvider:
    name = "anthropic"

    def __init__(self, model, timeout=30, max_retries=1, streaming=True):
        key = os.getenv("ANTHROPIC_API_KEY", "").strip()
        if not key:
            raise ValueError("ANTHROPIC_API_KEY is missing.")

        self.model = model
        self.timeout = timeout
        self.streaming = streaming
        self.client = AsyncAnthropic(api_key=key, timeout=timeout, max_retries=max_retries)

    async def chat(self, messages, on_token=None, stream=None):
        clean = [message for message in messages if message["role"] != "system"]
        system = next((message["content"] for message in messages if message["role"] == "system"), "")
        use_stream = self.streaming if stream is None else stream

        if use_stream:
            full = ""
            async with self.client.messages.stream(
                model=self.model,
                max_tokens=700,
                system=system,
                messages=clean,
            ) as stream_obj:
                async for text in stream_obj.text_stream:
                    full += text
                    if on_token:
                        on_token(text)
            return full or "No response received."

        response = await self.client.messages.create(
            model=self.model,
            max_tokens=700,
            system=system,
            messages=clean,
        )
        return response.content[0].text or "No response received."

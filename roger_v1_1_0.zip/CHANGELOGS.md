project-version: 1.1.0
project-date: 2026.5.9

# Changelogs

## 1.1.0

- Added AI-driven tool calling
- Added JSON tool-call parser
- Added multi-tool execution
- Added direct terminal command execution after approval
- Improved prompt box design
- Added `roger-cli-installation.py`
- Added manifest-based updater
- Added zip update support from external storage
- Added dependency install during update
- Added safer project file preservation
- Added update support through `python3 main.py --update`

## 1.0.0

- Initial public build

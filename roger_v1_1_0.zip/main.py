import asyncio
import os
import sys
from dotenv import load_dotenv
from prompt_toolkit import PromptSession
from prompt_toolkit.styles import Style
from prompt_toolkit.formatted_text import HTML

from core.agent import RogerAgent
from core.provider_loader import load_provider
from tui.ui import RogerUI

load_dotenv()

def clear_terminal():
    if os.getenv("CLEAR_ON_START", "true").lower() == "true":
        os.system("cls" if os.name == "nt" else "clear")

async def app():
    if "--update" in sys.argv:
        import roger_cli_installation
        await roger_cli_installation.main()
        return

    clear_terminal()

    ui = RogerUI()
    ui.show_intro()

    try:
        provider = load_provider()
    except Exception as error:
        ui.error("Startup failed", str(error))
        return

    agent = RogerAgent(provider, ui)
    session = PromptSession(
        style=Style.from_dict({
            "prompt": "ansicyan bold",
        })
    )

    ui.show_ready(provider)

    while True:
        try:
            prompt_message = ui.prompt_message()
            text = (await session.prompt_async(prompt_message)).strip()

            if not text:
                continue

            if text == "/exit":
                ui.goodbye()
                break

            await agent.run(text)

        except KeyboardInterrupt:
            ui.warning("Input cancelled", "Press /exit to close Roger.")
        except EOFError:
            ui.goodbye()
            break
        except Exception as error:
            ui.error("Unexpected error", str(error))

if __name__ == "__main__":
    asyncio.run(app())

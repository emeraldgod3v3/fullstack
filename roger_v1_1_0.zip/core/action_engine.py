import re

class ActionEngine:
    """
    Fast local planner for obvious actions.
    AI tool calls handle everything else.
    """

    def plan(self, prompt):
        text = prompt.strip()
        lower = text.lower()

        shell = self._shell_from_request(text)

        if shell:
            return [{"name": "terminal", "arguments": {"command": shell}}]

        if any(x in lower for x in [
            "show me the whole project folder content",
            "show project folder",
            "show project files",
            "list project files",
            "list project folder",
            "what files",
            "list files",
            "show files",
            "what is in this directory",
            "whats in this directory",
            "what's in this directory",
        ]):
            return [{"name": "terminal", "arguments": {"command": "find . -maxdepth 3 -print"}}]

        folder = self._folder(text)
        file_info = self._file(text)

        actions = []

        if folder:
            actions.append({"name": "create_folder", "arguments": {"path": folder}})

        if file_info:
            path = file_info["path"]

            if folder and "/" not in path:
                path = folder + "/" + path

            actions.append({"name": "write_file", "arguments": {"path": path, "content": file_info["content"]}})

        return actions

    def _shell_from_request(self, text):
        parts = text.split()

        direct_allowed = {
            "ls", "pwd", "echo", "cat", "python", "python3",
            "pip", "pip3", "git", "mkdir", "touch", "find", "tree"
        }

        if parts and parts[0] in direct_allowed:
            return text

        patterns = [
            r"(?:run|execute|use)\s+(?:the\s+)?(?:shell\s+)?(?:command\s+)?[`'\"]([^`'\"]+)[`'\"]",
            r"(?:run|execute)\s+(ls\s+.+|git\s+.+|find\s+.+|pwd|tree.*|cat\s+.+)$",
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)

            if match:
                return match.group(1).strip()

        lower = text.lower()

        if "show hidden files" in lower or "list all files" in lower:
            return "ls -la"

        if "show git status" in lower or "git status" in lower:
            return "git status"

        return None

    def _folder(self, text):
        lower = text.lower()

        if "temp folder" in lower:
            return "temp"

        patterns = [
            r"(?:create|make|build|generate)\s+(?:a\s+)?(?:new\s+)?(?:folder|directory)\s+(?:named|called\s+)?[\"']?([A-Za-z0-9_./ -]+?)[\"']?(?:\s+with|\s+and|\s+inside|\s+containing|$)",
            r"(?:create|make|build|generate)\s+[\"']?([A-Za-z0-9_./ -]+?)[\"']?\s+(?:folder|directory)"
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)

            if match:
                value = match.group(1).strip().strip("\"'").replace(" ", "_")

                if value:
                    return value

        return None

    def _file(self, text):
        lower = text.lower()

        if "file" not in lower and ".txt" not in lower and ".py" not in lower and ".md" not in lower and ".html" not in lower:
            return None

        return {"path": self._filename(text), "content": self._content(text)}

    def _filename(self, text):
        quoted = re.search(r"[\"']([^\"']+\.[A-Za-z0-9]+)[\"']", text)

        if quoted:
            return quoted.group(1).strip()

        direct = re.search(r"([A-Za-z0-9_./-]+\.[A-Za-z0-9]+)", text)

        if direct:
            return direct.group(1).strip()

        lower = text.lower()

        if "html" in lower:
            return "index.html"

        if "python file" in lower:
            return "main.py"

        if "markdown file" in lower:
            return "README.md"

        return "hello.txt"

    def _content(self, text):
        patterns = [
            r"(?:says|say|containing|contains|content|with text|text content)\s+[\"']([^\"']+)[\"']",
            r"(?:write|put)\s+[\"']([^\"']+)[\"']"
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)

            if match:
                return match.group(1)

        lower = text.lower()

        if "hello world" in lower and "html" in lower:
            return "<!DOCTYPE html>\\n<html>\\n<head>\\n  <title>Hello World</title>\\n</head>\\n<body>\\n  <h1>Hello World</h1>\\n</body>\\n</html>"

        if "hello world" in lower:
            return "hello world!"

        return ""

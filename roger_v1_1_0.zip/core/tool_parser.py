import json
import re

class ToolParser:
    def parse(self, text):
        cleaned = self._clean(text)

        try:
            data = json.loads(cleaned)
        except Exception:
            return []

        calls = []

        if isinstance(data, dict) and "tool_calls" in data:
            calls = data["tool_calls"]

        elif isinstance(data, dict) and "tool_call" in data:
            calls = [data["tool_call"]]

        elif isinstance(data, dict) and "name" in data and "arguments" in data:
            calls = [data]

        valid = []

        for call in calls:
            name = call.get("name")
            arguments = call.get("arguments", {})

            if name:
                valid.append({
                    "name": name,
                    "arguments": arguments
                })

        return valid

    def _clean(self, text):
        text = str(text).strip()

        if text.startswith("```"):
            text = text.replace("```json", "").replace("```", "").strip()

        first = text.find("{")
        last = text.rfind("}")

        if first != -1 and last != -1 and last > first:
            return text[first:last + 1]

        return text

import asyncio
from pathlib import Path

from commands.parser import SlashParser
from tools.registry import ToolRegistry
from core.permissions import PermissionManager
from core.action_engine import ActionEngine
from core.memory import WolfMemory
from core.tool_parser import ToolParser

def load_roger_prompt():
    path = Path("ROGER.md")

    if path.exists():
        return path.read_text(encoding="utf-8")

    return "You are Roger, a CLI AI agent."

class RogerAgent:
    def __init__(self, provider, ui):
        self.provider = provider
        self.ui = ui
        self.parser = SlashParser()
        self.tools = ToolRegistry()
        self.permissions = PermissionManager()
        self.action_engine = ActionEngine()
        self.memory = WolfMemory()
        self.tool_parser = ToolParser()
        self.messages = []
        self._refresh_system_prompt()

    async def run(self, prompt):
        command = self.parser.parse(prompt)

        if command:
            self.ui.assistant(self.handle_command(command))
            return

        memory = self.memory.detect_memory(prompt)

        if memory:
            result = self.memory.remember(memory)
            self.ui.assistant(result)
            self._refresh_system_prompt()
            return

        self.messages.append({"role": "user", "content": prompt})

        local_actions = self.action_engine.plan(prompt)

        if local_actions:
            await self._run_actions(local_actions)
            return

        await self._ai_or_chat(prompt)

    async def _ai_or_chat(self, prompt):
        tool_response = await self._ask_ai_for_tool_or_answer(prompt)
        tool_calls = self.tool_parser.parse(tool_response)

        if tool_calls:
            await self._run_actions(tool_calls)
            return

        response = tool_response

        if not response or response.strip() in ["", "No response received."]:
            response = self._fallback_response(prompt)

        self.messages.append({"role": "assistant", "content": response})
        self.ui.assistant(response)

    async def _ask_ai_for_tool_or_answer(self, prompt):
        self.ui.thinking()

        tool_prompt = {
            "role": "system",
            "content": (
                load_roger_prompt()
                + "\n\nUser memory:\n"
                + self.memory.read()
                + "\n\nIf the user asks for an action, return only JSON tool_calls. "
                + "If the user only asks a normal question, answer normally."
            )
        }

        ai_messages = [tool_prompt] + self.messages[-8:]

        try:
            return await asyncio.wait_for(
                self.provider.chat(
                    ai_messages,
                    None,
                    stream=False
                ),
                timeout=self.provider.timeout + 5
            )

        except asyncio.TimeoutError:
            return self._fallback_response(prompt)

    async def _run_actions(self, actions):
        results = []

        for action in actions:
            name = action["name"]
            args = action.get("arguments", {})

            if not await self._approve(name, args):
                self.ui.assistant(f"Tool request denied: {name}. Request ended.")
                return

            self.ui.tool_run(name, args)
            result = await self.tools.run(name, args)
            self.ui.tool_result(result)

            results.append(f"{name}: {result}")

        final = self._action_final(actions, results)

        self.messages.append({"role": "assistant", "content": final})
        self.ui.assistant(final)

    def _action_final(self, actions, results):
        names = [action["name"] for action in actions]
        summary = "\n".join(results)

        if "terminal" in names:
            return "Done. I ran the approved terminal command.\n\n" + summary

        if "create_folder" in names and "write_file" in names:
            return "Done. I created the folder and file.\n\n" + summary

        if "write_file" in names:
            return "Done. I created the file.\n\n" + summary

        if "create_folder" in names:
            return "Done. I created the folder.\n\n" + summary

        return "Done.\n\n" + summary

    async def _approve(self, name, args):
        if self.permissions.is_always_allowed(name):
            return True

        choice = self.ui.ask_tool_permission(name, args)

        if choice == "always":
            self.permissions.allow_always(name)
            return True

        return choice == "once"

    def _refresh_system_prompt(self):
        self.messages = [
            {
                "role": "system",
                "content": load_roger_prompt() + "\n\nUser memory:\n" + self.memory.read()
            }
        ]

    def _fallback_response(self, prompt):
        lower = prompt.lower()

        if "hi" in lower or "hello" in lower:
            return "Hello. I am Roger. What do you want to work on?"

        if "who are you" in lower:
            return "I am Roger, a CLI AI agent for terminal work, coding, files, memory, and project automation."

        return "I did not receive a strong model response. Try again, or ask me to run a command, list files, read a file, or create something."

    def handle_command(self, command):
        cmd = command["command"]

        if cmd == "/help":
            return "/help\n/about\n/provider\n/model\n/tools\n/permissions\n/memory\n/update\n/clear\n/exit"

        if cmd == "/about":
            return "ROGER v1.1.0 uses AI tool calls, ROGER.md, WOLF.md, and a manifest-based updater."

        if cmd == "/provider":
            return f"Provider: {self.provider.name}"

        if cmd == "/model":
            return f"Model: {self.provider.model}"

        if cmd == "/tools":
            return "\n".join(self.tools.list_tools())

        if cmd == "/permissions":
            allowed = self.permissions.list_allowed()
            return "\n".join(allowed) if allowed else "No tools are always allowed."

        if cmd == "/memory":
            return self.memory.read()

        if cmd == "/update":
            return "Run this in your terminal: python3 main.py --update"

        if cmd == "/clear":
            self._refresh_system_prompt()
            return "Chat memory cleared."

        return f"Unknown command: {cmd}"

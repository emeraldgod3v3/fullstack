import asyncio
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

import httpx
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

load_dotenv()

console = Console()

def get_version(path="CHANGELOGS.md"):
    file = Path(path)

    if not file.exists():
        return "0.0.0"

    for line in file.read_text(encoding="utf-8").splitlines():
        if line.startswith("project-version:"):
            return line.split(":", 1)[1].strip()

    return "0.0.0"

def print_header():
    console.print(
        Panel(
            "[bold cyan]R O G E R[/bold cyan]\n[green]CLI Installation Manager[/green]\n[dim]Updater for source-only deployments[/dim]",
            border_style="cyan",
            box=box.DOUBLE_EDGE,
        )
    )

def show_versions(current, latest):
    table = Table(title="Update Check", box=box.ROUNDED, border_style="green")
    table.add_column("Name", style="cyan")
    table.add_column("Version", style="white")
    table.add_row("Current", current)
    table.add_row("Latest", latest)
    console.print(table)

async def download(url, path):
    async with httpx.AsyncClient(timeout=120, follow_redirects=True) as client:
        response = await client.get(url)

    if response.status_code >= 400:
        raise RuntimeError(f"Download failed: HTTP {response.status_code}")

    path.write_bytes(response.content)

def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def find_root(folder):
    if (folder / "CHANGELOGS.md").exists():
        return folder

    for item in folder.iterdir():
        if item.is_dir() and (item / "CHANGELOGS.md").exists():
            return item

    return folder

def copy_update(src, dst):
    preserve = {
        ".env",
        ".roger_permissions.json",
        "WOLF.md",
        "workspace",
        "venv",
        ".git",
        "__pycache__",
    }

    for item in src.iterdir():
        if item.name in preserve:
            continue

        target = dst / item.name

        if item.is_dir():
            if target.exists():
                shutil.rmtree(target)
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)

def install_dependencies():
    if not Path("requirements.txt").exists():
        return

    console.print("[cyan]Installing dependencies...[/cyan]")
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", "requirements.txt"],
        check=False,
    )

async def main():
    print_header()

    manifest_url = os.getenv("ROGER_UPDATE_MANIFEST_URL", "").strip()

    if not manifest_url:
        console.print(
            Panel(
                "ROGER_UPDATE_MANIFEST_URL is empty.\n\n"
                "Upload your update zip to a secure storage provider, then create a manifest JSON.\n\n"
                "Recommended private/safe options:\n"
                "- Cloudflare R2 signed URL\n"
                "- AWS S3 presigned URL\n"
                "- Google Cloud Storage signed URL\n"
                "- Backblaze B2 private bucket\n"
                "- Supabase Storage signed URL\n\n"
                "Then set ROGER_UPDATE_MANIFEST_URL in .env.",
                title="[yellow]Updater Setup Needed[/yellow]",
                border_style="yellow",
            )
        )
        return

    current = get_version()

    try:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            manifest_path = tmp_path / "manifest.json"

            console.print("[cyan]Fetching update manifest...[/cyan]")
            await download(manifest_url, manifest_path)

            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

            latest = manifest.get("project-version", "0.0.0")
            zip_url = manifest.get("zip-url", "")
            expected_sha = manifest.get("sha256", "")

            show_versions(current, latest)

            if latest == current:
                console.print("[green]Roger is already up to date.[/green]")
                return

            if not zip_url:
                raise RuntimeError("Manifest missing zip-url")

            zip_path = tmp_path / "roger_update.zip"

            console.print("[cyan]Downloading update zip...[/cyan]")
            await download(zip_url, zip_path)

            if expected_sha:
                actual_sha = sha256(zip_path)

                if actual_sha.lower() != expected_sha.lower():
                    raise RuntimeError("SHA256 check failed. Update zip may be unsafe or corrupted.")

            extract_dir = tmp_path / "extract"
            extract_dir.mkdir()

            console.print("[cyan]Extracting update...[/cyan]")

            with zipfile.ZipFile(zip_path, "r") as z:
                z.extractall(extract_dir)

            root = find_root(extract_dir)

            console.print("[cyan]Copying source files...[/cyan]")
            copy_update(root, Path.cwd())

            install_dependencies()

            console.print(
                Panel(
                    f"Updated Roger from {current} to {latest}.\n\n"
                    "Run Roger again:\npython3 main.py",
                    title="[green]Update Complete[/green]",
                    border_style="green",
                )
            )

    except Exception as error:
        console.print(
            Panel(
                str(error),
                title="[red]Update Failed[/red]",
                border_style="red",
            )
        )

if __name__ == "__main__":
    asyncio.run(main())

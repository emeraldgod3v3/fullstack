import json
from commands.parser import SlashParser
from tools.registry import ToolRegistry
from core.permissions import PermissionManager

SYSTEM_PROMPT = """
You are Roger, a happy wolf CLI AI agent.
You answer clearly and directly.
You use tools only after user approval.
"""

TOOL_DECISION_PROMPT = """
Decide if the next user request needs a tool.

Return ONLY valid JSON.

If a tool is needed, return:
{
  "needs_tool": true,
  "tool_call": {
    "name": "tool_name",
    "arguments": {}
  }
}

If no tool is needed, return:
{
  "needs_tool": false
}

Available tools:
- create_folder: create a folder. args: path
- write_file: create or overwrite a file. args: path, content
- append_file: append text to a file. args: path, content
- read_file: read a file. args: path
- list_dir: list files and folders. args: path
- terminal: run a safe terminal command. args: command

Use a tool for requests asking to create, write, edit, read, list, or run commands.
Do not include explanation.
"""

FINAL_AFTER_TOOL_PROMPT = """
Give a short clear final answer to the user based on the tool result.
Do not call another tool unless another file or command action is still required.
"""

class RogerAgent:
    def __init__(self, provider, ui):
        self.provider = provider
        self.ui = ui
        self.parser = SlashParser()
        self.tools = ToolRegistry()
        self.permissions = PermissionManager()
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    async def run(self, prompt):
        command = self.parser.parse(prompt)

        if command:
            self.ui.assistant(self.handle_command(command))
            return

        self.messages.append({"role": "user", "content": prompt})

        decision = await self._decide_tool(prompt)

        if decision and decision.get("needs_tool"):
            await self._handle_tool_flow(decision)
            return

        self.ui.thinking()
        response = await self.provider.chat(self.messages, self.ui.stream_token, stream=True)
        self.messages.append({"role": "assistant", "content": response})
        self.ui.assistant(response, already_streamed=True)

    async def _decide_tool(self, prompt):
        decision_messages = [
            {"role": "system", "content": TOOL_DECISION_PROMPT},
            {"role": "user", "content": prompt}
        ]

        raw = await self.provider.chat(decision_messages, stream=False)

        try:
            return json.loads(self._clean_json(raw))
        except Exception:
            return {"needs_tool": False}

    async def _handle_tool_flow(self, decision):
        call = decision.get("tool_call", {})
        tool_name = call.get("name")
        tool_args = call.get("arguments", {})

        if not tool_name:
            self.ui.error("Tool error", "The model requested a tool but did not provide a tool name.")
            return

        allowed = await self._approve_tool(tool_name, tool_args)

        if not allowed:
            denied = f"Tool request denied: {tool_name}. Request ended."
            self.messages.append({"role": "assistant", "content": denied})
            self.ui.assistant(denied)
            return

        self.ui.tool_run(tool_name, tool_args)
        result = await self.tools.run(tool_name, tool_args)
        self.ui.tool_result(result)

        self.messages.append({
            "role": "assistant",
            "content": json.dumps({"tool_call": {"name": tool_name, "arguments": tool_args}})
        })
        self.messages.append({
            "role": "user",
            "content": f"Tool result for {tool_name}: {result}\n{FINAL_AFTER_TOOL_PROMPT}"
        })

        follow_decision = await self._decide_tool(self.messages[-1]["content"])

        if follow_decision and follow_decision.get("needs_tool"):
            await self._handle_tool_flow(follow_decision)
            return

        self.ui.thinking()
        final = await self.provider.chat(self.messages, self.ui.stream_token, stream=True)
        self.messages.append({"role": "assistant", "content": final})
        self.ui.assistant(final, already_streamed=True)

    async def _approve_tool(self, tool_name, tool_args):
        if self.permissions.is_always_allowed(tool_name):
            return True

        choice = self.ui.ask_tool_permission(tool_name, tool_args)

        if choice == "always":
            self.permissions.allow_always(tool_name)
            return True

        if choice == "once":
            return True

        return False

    def _clean_json(self, text):
        text = str(text).strip()

        if text.startswith("```"):
            text = text.replace("```json", "").replace("```", "").strip()

        first = text.find("{")
        last = text.rfind("}")

        if first != -1 and last != -1:
            return text[first:last + 1]

        return text

    def handle_command(self, command):
        cmd = command["command"]

        if cmd == "/help":
            return """
Commands:

/help          Show commands
/about         Show Roger info
/provider      Show active provider
/model         Show active model
/tools         Show registered tools
/permissions   Show always-allowed tools
/clear         Clear chat memory
/exit          Exit Roger
"""

        if cmd == "/about":
            return """
Roger is a happy wolf CLI AI agent.

Features:
- Tool decision step before execution
- Arrow-key approval menu
- Streaming text responses
- NVIDIA GLM-4.7 default
- Responsive TUI
- Workspace-safe file operations
- Safe terminal execution
- Clean terminal launch
"""

        if cmd == "/provider":
            return f"Provider: {self.provider.name}"

        if cmd == "/model":
            return f"Model: {self.provider.model}"

        if cmd == "/tools":
            return "\n".join(self.tools.list_tools())

        if cmd == "/permissions":
            allowed = self.permissions.list_allowed()
            return "\n".join(allowed) if allowed else "No tools are always allowed."

        if cmd == "/clear":
            self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            return "Chat memory cleared."

        return f"Unknown command: {cmd}"

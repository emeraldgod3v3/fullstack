# Roger Agent Clean TUI Edition

This version fixes the messy streaming panels and replaces number selection with an arrow-key approval menu.

## Fixed in this build

- Terminal clears before Roger launches
- Tool JSON is no longer streamed into the chat
- Roger pauses before tool execution
- Tool approval uses arrow keys
- Simple readable errors
- Fixed literal `\n` showing in TUI
- Cleaner mobile and desktop layout
- GLM-4.7 remains default
- Streaming still works for normal replies

## Setup

```bash
unzip roger_agent_tui_clean.zip
cd roger_agent_tui_clean
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Add your key:

```env
NVIDIA_API_KEY=your_key_here
```

Run:

```bash
python3 main.py
```

## Test

Ask:

```txt
create a temp folder with a text file containing hello world
```

Roger should pause and show an arrow-key menu.

## Approval choices

- Always allow the tool
- Allow once
- Don't approve

If denied, Roger ends the request.

## Files are written inside

```txt
workspace/
```

## Useful commands

```txt
/help
/about
/provider
/model
/tools
/permissions
/clear
/exit
```

from rich.console import Console
from rich.panel import Panel
from rich.align import Align
from rich.text import Text
from rich.table import Table
from rich.markdown import Markdown
from rich import box

WOLF_LOGO = '''
        /\\_/\\\\
       ( ^ᴥ^ )
      /|  🐺  |\\\\
     /_|_____|_\\\\

        ROGER
'''

class RogerUI:
    def __init__(self):
        self.console = Console()

    def show_intro(self):
        title = Text()
        title.append(WOLF_LOGO, style="bold cyan")
        title.append("\\nHappy Wolf AI Terminal Agent", style="bold green")

        self.console.print(
            Panel(
                Align.center(title),
                title="[bold cyan]Roger[/bold cyan]",
                subtitle="Claude Code style CLI agent",
                border_style="cyan",
                box=box.DOUBLE
            )
        )

        table = Table(title="Quick Commands", box=box.ROUNDED, border_style="green")
        table.add_column("Command", style="cyan")
        table.add_column("Action", style="white")
        table.add_row("/help", "Show all commands")
        table.add_row("/provider", "Show active provider")
        table.add_row("/model", "Show active model")
        table.add_row("/clear", "Clear chat memory")
        table.add_row("/exit", "Quit Roger")
        self.console.print(table)

    def show_ready(self, provider):
        self.console.print(
            Panel(
                f"[green]Provider:[/green] {provider.name}\\n"
                f"[green]Model:[/green] {provider.model}\\n"
                f"[green]Status:[/green] Ready",
                title="Session",
                border_style="green",
                box=box.ROUNDED
            )
        )

    def thinking(self):
        self.console.print("[dim cyan]Roger is thinking...[/dim cyan]")

    def assistant(self, text):
        self.console.print(
            Panel(
                Markdown(str(text)),
                title="[bold cyan]Roger 🐺[/bold cyan]",
                border_style="cyan",
                box=box.ROUNDED
            )
        )

    def warning(self, text):
        self.console.print(Panel(str(text), title="Warning", border_style="yellow"))

    def error(self, text):
        self.console.print(Panel(str(text), title="[bold red]Error[/bold red]", border_style="red"))

    def goodbye(self):
        self.console.print("[bold cyan]Roger closed. Goodbye.[/bold cyan]")

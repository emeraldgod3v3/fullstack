# Roger Wolf TUI

Roger is a happy wolf themed CLI AI agent.

## Fixed

- NVIDIA timeout crash
- Added retries
- Added timeout settings
- Added better TUI
- Added conversation history
- Added provider info
- Added slash commands

## Setup

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Add your NVIDIA key:

```env
NVIDIA_API_KEY=your_key_here
```

Run:

```bash
python3 main.py
```

## Commands

```txt
/help
/about
/provider
/model
/tools
/clear
/exit
```

## If NVIDIA still times out

Edit `.env`:

```env
REQUEST_TIMEOUT=240
MAX_RETRIES=3
```

Then run again:

```bash
python3 main.py
```

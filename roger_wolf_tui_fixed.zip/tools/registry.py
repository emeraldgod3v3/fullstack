from tools.terminal import terminal_tool
from tools.filesystem import read_file, write_file

class ToolRegistry:
    def __init__(self):
        self.tools = {
            "terminal": terminal_tool,
            "read_file": read_file,
            "write_file": write_file
        }

    def list_tools(self):
        return list(self.tools.keys())

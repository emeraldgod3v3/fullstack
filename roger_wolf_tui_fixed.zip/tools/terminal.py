import asyncio

SAFE_COMMANDS = ["ls", "pwd", "echo", "cat", "python", "python3", "pip", "pip3", "git"]

async def terminal_tool(command):
    base = command.split()[0]

    if base not in SAFE_COMMANDS:
        return "Blocked command"

    process = await asyncio.create_subprocess_shell(
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )

    stdout, stderr = await process.communicate()

    if stderr:
        return stderr.decode()

    return stdout.decode()

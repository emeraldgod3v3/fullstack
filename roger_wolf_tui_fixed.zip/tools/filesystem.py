from pathlib import Path

async def read_file(path):
    return Path(path).read_text()

async def write_file(path, content):
    Path(path).write_text(content)
    return "File written"

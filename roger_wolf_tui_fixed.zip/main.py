import asyncio
from dotenv import load_dotenv
from prompt_toolkit import PromptSession
from prompt_toolkit.styles import Style

from core.agent import RogerAgent
from core.provider_loader import load_provider
from tui.ui import RogerUI

load_dotenv()

async def main():
    ui = RogerUI()
    ui.show_intro()

    try:
        provider = load_provider()
    except Exception as error:
        ui.error(str(error))
        return

    agent = RogerAgent(provider=provider, ui=ui)

    session = PromptSession(
        style=Style.from_dict({"prompt": "ansibrightcyan bold"})
    )

    ui.show_ready(provider)

    while True:
        try:
            user_input = await session.prompt_async(
                [("class:prompt", "Roger 🐺 > ")]
            )
            user_input = user_input.strip()

            if not user_input:
                continue

            if user_input == "/exit":
                ui.goodbye()
                break

            response = await agent.run(user_input)
            ui.assistant(response)

        except KeyboardInterrupt:
            ui.warning("Press /exit to close Roger.")
        except EOFError:
            ui.goodbye()
            break
        except Exception as error:
            ui.error(f"Unexpected error: {error}")

if __name__ == "__main__":
    asyncio.run(main())

import os
from providers.nvidia_provider import NvidiaProvider
from providers.openai_provider import OpenAIProvider
from providers.anthropic_provider import AnthropicProvider

def load_provider():
    provider = os.getenv("DEFAULT_PROVIDER", "nvidia").strip().lower()
    timeout = float(os.getenv("REQUEST_TIMEOUT", "180"))
    max_retries = int(os.getenv("MAX_RETRIES", "3"))

    if provider == "openai":
        return OpenAIProvider(os.getenv("OPENAI_MODEL", "gpt-4.1"), timeout, max_retries)

    if provider == "anthropic":
        return AnthropicProvider(os.getenv("ANTHROPIC_MODEL", "claude-3-7-sonnet-latest"), timeout, max_retries)

    if provider == "nvidia":
        return NvidiaProvider(os.getenv("NVIDIA_MODEL", "meta/llama-3.1-70b-instruct"), timeout, max_retries)

    raise ValueError("Unknown DEFAULT_PROVIDER. Use nvidia, openai, or anthropic.")

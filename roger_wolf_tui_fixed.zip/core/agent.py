from commands.parser import SlashParser
from tools.registry import ToolRegistry

SYSTEM_PROMPT = '''
You are Roger, a helpful wolf-themed CLI AI agent.
You answer clearly.
You help with coding, Linux commands, debugging, planning, and project work.
'''

class RogerAgent:
    def __init__(self, provider, ui):
        self.provider = provider
        self.ui = ui
        self.parser = SlashParser()
        self.tools = ToolRegistry()
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    async def run(self, prompt):
        command = self.parser.parse(prompt)

        if command:
            return self.handle_command(command)

        self.messages.append({"role": "user", "content": prompt})
        self.ui.thinking()

        response = await self.provider.chat(self.messages)

        self.messages.append({"role": "assistant", "content": response})
        return response

    def handle_command(self, command):
        cmd = command["command"]

        if cmd == "/help":
            return '''
Commands:

/help       Show commands
/about      Show Roger info
/provider   Show active provider
/model      Show active model
/tools      Show registered tools
/clear      Clear chat memory
/exit       Exit Roger
'''

        if cmd == "/about":
            return '''
Roger is a happy wolf CLI AI agent.

Features:
- NVIDIA default provider
- OpenAI and Anthropic optional
- Better TUI
- Conversation memory
- Slash commands
- Tool registry
- Timeout and retry handling
'''

        if cmd == "/provider":
            return f"Provider: {self.provider.name}"

        if cmd == "/model":
            return f"Model: {self.provider.model}"

        if cmd == "/tools":
            return "\n".join(self.tools.list_tools())

        if cmd == "/clear":
            self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            return "Chat memory cleared."

        return f"Unknown command: {cmd}"

import os
from dotenv import load_dotenv
from anthropic import AsyncAnthropic

load_dotenv()

class AnthropicProvider:
    name = "anthropic"

    def __init__(self, model, timeout=180, max_retries=3):
        api_key = os.getenv("ANTHROPIC_API_KEY", "").strip()

        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY is missing. Add it inside your .env file.")

        self.model = model
        self.client = AsyncAnthropic(api_key=api_key, timeout=timeout, max_retries=max_retries)

    async def chat(self, messages):
        try:
            clean_messages = [m for m in messages if m["role"] != "system"]
            response = await self.client.messages.create(
                model=self.model,
                max_tokens=2048,
                system="You are Roger, a helpful CLI AI agent.",
                messages=clean_messages
            )
            return response.content[0].text
        except Exception as error:
            return f"Anthropic provider error: {error}"

import os
from dotenv import load_dotenv
from openai import AsyncOpenAI

load_dotenv()

class OpenAIProvider:
    name = "openai"

    def __init__(self, model, timeout=180, max_retries=3):
        api_key = os.getenv("OPENAI_API_KEY", "").strip()

        if not api_key:
            raise ValueError("OPENAI_API_KEY is missing. Add it inside your .env file.")

        self.model = model
        self.client = AsyncOpenAI(api_key=api_key, timeout=timeout, max_retries=max_retries)

    async def chat(self, messages):
        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages
            )
            return response.choices[0].message.content
        except Exception as error:
            return f"OpenAI provider error: {error}"

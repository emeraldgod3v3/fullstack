import asyncio
import os
import httpx
from dotenv import load_dotenv

load_dotenv()

class NvidiaProvider:
    name = "nvidia"

    def __init__(self, model, timeout=180, max_retries=3):
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self.base_url = os.getenv(
            "NVIDIA_BASE_URL",
            "https://integrate.api.nvidia.com/v1/chat/completions"
        )
        self.api_key = os.getenv("NVIDIA_API_KEY", "").strip()

        if not self.api_key:
            raise ValueError("NVIDIA_API_KEY is missing. Add it inside your .env file.")

    async def chat(self, messages):
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 2048,
            "stream": False
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

        timeout = httpx.Timeout(
            connect=30.0,
            read=self.timeout,
            write=30.0,
            pool=30.0
        )

        last_error = None

        for attempt in range(1, self.max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=timeout) as client:
                    response = await client.post(
                        self.base_url,
                        headers=headers,
                        json=payload
                    )

                if response.status_code >= 400:
                    return self._format_http_error(response)

                data = response.json()
                return data["choices"][0]["message"]["content"]

            except (httpx.ReadTimeout, httpx.ConnectTimeout) as error:
                last_error = error
                if attempt < self.max_retries:
                    await asyncio.sleep(1.5 * attempt)
                    continue

                return (
                    "NVIDIA request timed out after retries. "
                    "Increase REQUEST_TIMEOUT in .env to 240, or try a smaller/faster NVIDIA model."
                )

            except httpx.RequestError as error:
                last_error = error
                if attempt < self.max_retries:
                    await asyncio.sleep(1.5 * attempt)
                    continue

                return f"NVIDIA network error: {error}"

            except Exception as error:
                return f"NVIDIA provider error: {error}"

        return f"NVIDIA request failed: {last_error}"

    def _format_http_error(self, response):
        try:
            details = response.json()
        except Exception:
            details = response.text

        return f"NVIDIA API error {response.status_code}: {details}"

# Roger Agent Tool Calling Edition

Roger is a happy wolf CLI AI agent with real tool calling, streaming, permission prompts, and a responsive TUI.

## New features

- Real tool calling
- User approval before tool execution
- Three approval choices:
  1. Always allow the command
  2. Allow once
  3. Don't approve
- Streaming responses
- GLM-4.7 default model
- Workspace file creation
- Safe terminal commands
- Better desktop and mobile TUI
- Persistent always-allow permissions

## Setup

```bash
unzip roger_agent_toolcalling.zip
cd roger_agent_toolcalling
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Add your NVIDIA API key:

```env
NVIDIA_API_KEY=your_key_here
```

Run:

```bash
python3 main.py
```

## Test tool calling

Ask:

```txt
create a folder named test and create hello.txt inside it
```

Roger should ask permission before running the tool.

## Workspace

Roger writes files only inside:

```txt
workspace/
```

## Commands

```txt
/help
/about
/provider
/model
/tools
/permissions
/clear
/exit
```

## If GLM-4.7 times out

Edit `.env`:

```env
REQUEST_TIMEOUT=300
MAX_RETRIES=3
```

## Default model

```env
NVIDIA_MODEL=z-ai/glm4.7
```

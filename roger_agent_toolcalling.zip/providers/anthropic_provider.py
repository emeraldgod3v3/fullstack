import os
from dotenv import load_dotenv
from anthropic import AsyncAnthropic

load_dotenv()

class AnthropicProvider:
    name = "anthropic"

    def __init__(self, model, timeout=240, max_retries=3, streaming=True):
        api_key = os.getenv("ANTHROPIC_API_KEY", "").strip()

        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY is missing. Add it inside your .env file.")

        self.model = model
        self.streaming = streaming
        self.client = AsyncAnthropic(api_key=api_key, timeout=timeout, max_retries=max_retries)

    async def chat(self, messages, on_token=None):
        try:
            clean_messages = [m for m in messages if m["role"] != "system"]
            system = next((m["content"] for m in messages if m["role"] == "system"), "")

            if self.streaming:
                full = ""

                async with self.client.messages.stream(
                    model=self.model,
                    max_tokens=2048,
                    system=system,
                    messages=clean_messages
                ) as stream:
                    async for text in stream.text_stream:
                        full += text
                        if on_token:
                            on_token(text)

                return full

            response = await self.client.messages.create(
                model=self.model,
                max_tokens=2048,
                system=system,
                messages=clean_messages
            )
            return response.content[0].text

        except Exception as error:
            return f"Anthropic provider error: {error}"

import asyncio
import json
import os
import httpx
from dotenv import load_dotenv

load_dotenv()

class NvidiaProvider:
    name = "nvidia"

    def __init__(self, model, timeout=240, max_retries=3, streaming=True):
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self.streaming = streaming
        self.base_url = os.getenv("NVIDIA_BASE_URL", "https://integrate.api.nvidia.com/v1/chat/completions")
        self.api_key = os.getenv("NVIDIA_API_KEY", "").strip()

        if not self.api_key:
            raise ValueError("NVIDIA_API_KEY is missing. Add it inside your .env file.")

    async def chat(self, messages, on_token=None):
        if self.streaming:
            return await self._stream_chat(messages, on_token)

        return await self._normal_chat(messages)

    async def _normal_chat(self, messages):
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.3,
            "max_tokens": 2048,
            "stream": False
        }

        response = await self._post_json(payload)
        data = response.json()
        return data["choices"][0]["message"]["content"]

    async def _stream_chat(self, messages, on_token=None):
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.3,
            "max_tokens": 2048,
            "stream": True
        }

        final_text = ""
        last_error = None

        for attempt in range(1, self.max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=self._timeout()) as client:
                    async with client.stream("POST", self.base_url, headers=self._headers(), json=payload) as response:
                        if response.status_code >= 400:
                            body = await response.aread()
                            return f"NVIDIA API error {response.status_code}: {body.decode(errors='ignore')}"

                        async for line in response.aiter_lines():
                            if not line:
                                continue

                            if line.startswith("data: "):
                                line = line[6:]

                            if line.strip() == "[DONE]":
                                break

                            try:
                                chunk = json.loads(line)
                                delta = chunk["choices"][0].get("delta", {})
                                token = delta.get("content", "")

                                if token:
                                    final_text += token
                                    if on_token:
                                        on_token(token)
                            except Exception:
                                continue

                if final_text:
                    return final_text

            except (httpx.ReadTimeout, httpx.ConnectTimeout) as error:
                last_error = error
                if attempt < self.max_retries:
                    await asyncio.sleep(1.5 * attempt)
                    continue

                return "NVIDIA request timed out. Increase REQUEST_TIMEOUT in .env to 300."

            except httpx.RequestError as error:
                last_error = error
                if attempt < self.max_retries:
                    await asyncio.sleep(1.5 * attempt)
                    continue

                return f"NVIDIA network error: {error}"

        return f"NVIDIA request failed: {last_error}"

    async def _post_json(self, payload):
        last_error = None

        for attempt in range(1, self.max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=self._timeout()) as client:
                    response = await client.post(self.base_url, headers=self._headers(), json=payload)

                if response.status_code >= 400:
                    raise RuntimeError(f"NVIDIA API error {response.status_code}: {response.text}")

                return response

            except Exception as error:
                last_error = error
                if attempt < self.max_retries:
                    await asyncio.sleep(1.5 * attempt)
                    continue

        raise last_error

    def _headers(self):
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

    def _timeout(self):
        return httpx.Timeout(connect=30.0, read=self.timeout, write=30.0, pool=30.0)

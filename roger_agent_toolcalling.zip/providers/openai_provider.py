import os
from dotenv import load_dotenv
from openai import AsyncOpenAI

load_dotenv()

class OpenAIProvider:
    name = "openai"

    def __init__(self, model, timeout=240, max_retries=3, streaming=True):
        api_key = os.getenv("OPENAI_API_KEY", "").strip()

        if not api_key:
            raise ValueError("OPENAI_API_KEY is missing. Add it inside your .env file.")

        self.model = model
        self.streaming = streaming
        self.client = AsyncOpenAI(api_key=api_key, timeout=timeout, max_retries=max_retries)

    async def chat(self, messages, on_token=None):
        try:
            if self.streaming:
                stream = await self.client.chat.completions.create(model=self.model, messages=messages, stream=True)
                full = ""

                async for chunk in stream:
                    token = chunk.choices[0].delta.content or ""
                    full += token

                    if token and on_token:
                        on_token(token)

                return full

            response = await self.client.chat.completions.create(model=self.model, messages=messages)
            return response.choices[0].message.content

        except Exception as error:
            return f"OpenAI provider error: {error}"

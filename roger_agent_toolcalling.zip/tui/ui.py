import json
from rich.console import Console
from rich.panel import Panel
from rich.align import Align
from rich.text import Text
from rich.table import Table
from rich.markdown import Markdown
from rich.live import Live
from rich import box

WOLF_DESKTOP = """
        /\\_/\\\\
       ( ^ᴥ^ )
      /|  🐺  |\\\\
     /_|_____|_\\\\

        ROGER
"""

WOLF_MOBILE = """
 /\\_/\\\\
( ^ᴥ^ )
  🐺
ROGER
"""

class RogerUI:
    def __init__(self):
        self.console = Console()
        self.live = None
        self.stream_buffer = ""

    def is_mobile(self):
        return self.console.width < 75

    def show_intro(self):
        logo = WOLF_MOBILE if self.is_mobile() else WOLF_DESKTOP

        title = Text()
        title.append(logo, style="bold cyan")
        title.append("\\nHappy Wolf AI Agent", style="bold green")

        self.console.print(
            Panel(
                Align.center(title),
                title="[bold cyan]Roger[/bold cyan]",
                subtitle="Tool calling CLI agent",
                border_style="cyan",
                box=box.ROUNDED if self.is_mobile() else box.DOUBLE
            )
        )

        self.show_commands()

    def show_commands(self):
        table = Table(
            title="Quick Commands",
            box=box.SIMPLE if self.is_mobile() else box.ROUNDED,
            border_style="green",
            show_lines=not self.is_mobile()
        )

        table.add_column("Command", style="cyan", no_wrap=True)
        table.add_column("Action", style="white")

        rows = [
            ("/help", "Commands"),
            ("/provider", "Provider"),
            ("/model", "Model"),
            ("/tools", "Tools"),
            ("/permissions", "Allowed tools"),
            ("/clear", "Clear memory"),
            ("/exit", "Quit"),
        ]

        for command, action in rows:
            table.add_row(command, action)

        self.console.print(table)

    def show_ready(self, provider):
        self.console.print(
            Panel(
                f"[green]Provider:[/green] {provider.name}\\n"
                f"[green]Model:[/green] {provider.model}\\n"
                f"[green]Status:[/green] Ready",
                title="Session",
                border_style="green",
                box=box.ROUNDED
            )
        )

    def thinking(self):
        self.stream_buffer = ""
        self.console.print("[dim cyan]Roger is thinking...[/dim cyan]")

    def stream_token(self, token):
        self.stream_buffer += token
        panel = Panel(
            Markdown(self.stream_buffer),
            title="[bold cyan]Roger 🐺 streaming[/bold cyan]",
            border_style="cyan",
            box=box.ROUNDED
        )

        if self.live is None:
            self.live = Live(panel, console=self.console, refresh_per_second=12)
            self.live.start()
        else:
            self.live.update(panel)

    def assistant(self, text, already_streamed=False):
        if self.live is not None:
            self.live.stop()
            self.live = None
            if already_streamed:
                return

        self.console.print(
            Panel(
                Markdown(str(text)),
                title="[bold cyan]Roger 🐺[/bold cyan]",
                border_style="cyan",
                box=box.ROUNDED
            )
        )

    def ask_tool_permission(self, tool_name, tool_args):
        args = json.dumps(tool_args, indent=2)

        self.console.print(
            Panel(
                f"[bold]Tool requested:[/bold] {tool_name}\\n\\n"
                f"[bold]Arguments:[/bold]\\n{args}\\n\\n"
                "[cyan]1[/cyan]. Always allow this command\\n"
                "[cyan]2[/cyan]. Allow once\\n"
                "[cyan]3[/cyan]. Don't approve",
                title="[yellow]Tool Permission[/yellow]",
                border_style="yellow",
                box=box.ROUNDED
            )
        )

        while True:
            choice = self.console.input("[yellow]Choose 1, 2, or 3: [/yellow]").strip()

            if choice in ["1", "2", "3"]:
                return choice

            self.console.print("[red]Invalid choice.[/red]")

    def tool_run(self, name, args):
        self.console.print(
            Panel(
                json.dumps(args, indent=2),
                title=f"[magenta]Running tool: {name}[/magenta]",
                border_style="magenta",
                box=box.ROUNDED
            )
        )

    def tool_result(self, result):
        self.console.print(
            Panel(
                str(result),
                title="[green]Tool Result[/green]",
                border_style="green",
                box=box.ROUNDED
            )
        )

    def warning(self, text):
        self.console.print(Panel(str(text), title="Warning", border_style="yellow"))

    def error(self, text):
        self.console.print(Panel(str(text), title="[bold red]Error[/bold red]", border_style="red"))

    def goodbye(self):
        self.console.print("[bold cyan]Roger closed. Goodbye.[/bold cyan]")

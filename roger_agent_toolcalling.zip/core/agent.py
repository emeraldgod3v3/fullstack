import json
from commands.parser import SlashParser
from tools.registry import ToolRegistry
from core.permissions import PermissionManager

SYSTEM_PROMPT = """
You are Roger, a happy wolf CLI AI agent.

You have tool calling access.

When you need a tool, respond ONLY with valid JSON in this exact format:

{
  "tool_call": {
    "name": "tool_name",
    "arguments": {
      "key": "value"
    }
  }
}

Available tools:
- create_folder: create a folder. args: path
- write_file: create or overwrite a file. args: path, content
- append_file: append text to a file. args: path, content
- read_file: read a file. args: path
- list_dir: list files and folders. args: path
- terminal: run a safe terminal command. args: command

Rules:
- Use tools when the user asks you to create, edit, read, list, or run something.
- Do not pretend you executed a command. Use a tool.
- After a tool result, explain what happened clearly.
- Keep answers direct.
"""

class RogerAgent:
    def __init__(self, provider, ui):
        self.provider = provider
        self.ui = ui
        self.parser = SlashParser()
        self.tools = ToolRegistry()
        self.permissions = PermissionManager()
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    async def run(self, prompt):
        command = self.parser.parse(prompt)

        if command:
            self.ui.assistant(self.handle_command(command))
            return

        self.messages.append({"role": "user", "content": prompt})

        for _ in range(5):
            self.ui.thinking()
            response = await self.provider.chat(self.messages, self.ui.stream_token)

            parsed = self._parse_tool_call(response)

            if not parsed:
                self.messages.append({"role": "assistant", "content": response})
                self.ui.assistant(response, already_streamed=True)
                return

            tool_name = parsed["name"]
            tool_args = parsed["arguments"]

            allowed = await self._approve_tool(tool_name, tool_args)

            if not allowed:
                denied = f"Tool request denied: {tool_name}. Request ended."
                self.messages.append({"role": "assistant", "content": denied})
                self.ui.assistant(denied)
                return

            self.ui.tool_run(tool_name, tool_args)
            result = await self.tools.run(tool_name, tool_args)
            self.ui.tool_result(result)

            self.messages.append({"role": "assistant", "content": response})
            self.messages.append({"role": "user", "content": f"Tool result for {tool_name}: {result}"})

        final = "Tool loop stopped after 5 steps to avoid an infinite loop."
        self.messages.append({"role": "assistant", "content": final})
        self.ui.assistant(final)

    async def _approve_tool(self, tool_name, tool_args):
        if self.permissions.is_always_allowed(tool_name):
            return True

        choice = self.ui.ask_tool_permission(tool_name, tool_args)

        if choice == "1":
            self.permissions.allow_always(tool_name)
            return True

        if choice == "2":
            return True

        return False

    def _parse_tool_call(self, response):
        text = response.strip()

        if text.startswith("```"):
            text = text.replace("```json", "").replace("```", "").strip()

        try:
            data = json.loads(text)
        except Exception:
            return None

        call = data.get("tool_call")

        if not call:
            return None

        return {
            "name": call.get("name"),
            "arguments": call.get("arguments", {})
        }

    def handle_command(self, command):
        cmd = command["command"]

        if cmd == "/help":
            return """
Commands:

/help          Show commands
/about         Show Roger info
/provider      Show active provider
/model         Show active model
/tools         Show registered tools
/permissions   Show always-allowed tools
/clear         Clear chat memory
/exit          Exit Roger
"""

        if cmd == "/about":
            return """
Roger is a happy wolf CLI AI agent.

Features:
- Real tool calling
- Tool approval prompts
- Always allow or one-time allow
- Streaming responses
- NVIDIA GLM-4.7 default
- Responsive TUI
- Workspace file operations
- Safe terminal execution
"""

        if cmd == "/provider":
            return f"Provider: {self.provider.name}"

        if cmd == "/model":
            return f"Model: {self.provider.model}"

        if cmd == "/tools":
            return "\n".join(self.tools.list_tools())

        if cmd == "/permissions":
            allowed = self.permissions.list_allowed()
            return "\n".join(allowed) if allowed else "No tools are always allowed."

        if cmd == "/clear":
            self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            return "Chat memory cleared."

        return f"Unknown command: {cmd}"

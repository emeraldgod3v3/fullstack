import asyncio
import os
from dotenv import load_dotenv
from rich.console import Console

from core.agent import RogerAgent
from providers.openai_provider import OpenAIProvider
from providers.anthropic_provider import AnthropicProvider
from providers.nvidia_provider import NvidiaProvider

load_dotenv()

console = Console()

def load_provider():
    provider = os.getenv("DEFAULT_PROVIDER", "nvidia")

    if provider == "openai":
        return OpenAIProvider(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1")
        )

    if provider == "anthropic":
        return AnthropicProvider(
            model=os.getenv(
                "ANTHROPIC_MODEL",
                "claude-3-7-sonnet-latest"
            )
        )

    return NvidiaProvider(
        model=os.getenv(
            "NVIDIA_MODEL",
            "meta/llama-3.1-70b-instruct"
        )
    )

async def main():
    agent = RogerAgent(load_provider())

    console.print("[bold green]Roger CLI Started[/bold green]")

    while True:
        user_input = input("Roger > ")

        if user_input.strip() == "/exit":
            break

        response = await agent.run(user_input)

        console.print(response)

if __name__ == "__main__":
    asyncio.run(main())

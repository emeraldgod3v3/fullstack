from commands.parser import SlashParser

class RogerAgent:
    def __init__(self, provider):
        self.provider = provider
        self.parser = SlashParser()

    async def run(self, prompt):
        command = self.parser.parse(prompt)

        if command:
            return self.handle_command(command)

        messages = [
            {
                "role": "user",
                "content": prompt
            }
        ]

        return await self.provider.chat(messages)

    def handle_command(self, command):
        if command["command"] == "/help":
            return '''
/help
/exit
/tools
'''

        return "Unknown command"

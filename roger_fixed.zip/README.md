# Roger Fixed Version

## Fixes

- NVIDIA is now the default provider
- Missing API keys are handled correctly
- Optional providers supported

## Setup

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Add:

```env
NVIDIA_API_KEY=your_key_here
```

Run:

```bash
python3 main.py
```

import os
from dotenv import load_dotenv
from anthropic import AsyncAnthropic

load_dotenv()

class AnthropicProvider:
    def __init__(self, model):
        api_key = os.getenv("ANTHROPIC_API_KEY")

        if not api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY missing in .env"
            )

        self.model = model
        self.client = AsyncAnthropic(api_key=api_key)

    async def chat(self, messages):
        response = await self.client.messages.create(
            model=self.model,
            max_tokens=2048,
            messages=messages
        )

        return response.content[0].text

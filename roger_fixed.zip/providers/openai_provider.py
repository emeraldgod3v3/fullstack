import os
from dotenv import load_dotenv
from openai import AsyncOpenAI

load_dotenv()

class OpenAIProvider:
    def __init__(self, model):
        api_key = os.getenv("OPENAI_API_KEY")

        if not api_key:
            raise ValueError(
                "OPENAI_API_KEY missing in .env"
            )

        self.model = model
        self.client = AsyncOpenAI(api_key=api_key)

    async def chat(self, messages):
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=messages
        )

        return response.choices[0].message.content

import os
import httpx
from dotenv import load_dotenv

load_dotenv()

class NvidiaProvider:
    def __init__(self, model):
        self.model = model
        self.api_key = os.getenv("NVIDIA_API_KEY")

        if not self.api_key:
            raise ValueError(
                "NVIDIA_API_KEY missing in .env"
            )

    async def chat(self, messages):
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://integrate.api.nvidia.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}"
                },
                json={
                    "model": self.model,
                    "messages": messages,
                    "temperature": 0.7,
                    "max_tokens": 2048
                }
            )

        data = response.json()

        return data["choices"][0]["message"]["content"]

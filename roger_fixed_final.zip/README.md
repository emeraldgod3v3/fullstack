# Roger Fixed Final

Fixed:

```txt
SyntaxError: unterminated string literal
```

## Copy-paste install command

```bash
rm -rf roger && unzip roger_fixed_final.zip -d roger && cd roger && python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt && cp .env.example .env && nano .env && python3 main.py
```

Add your API key:

```env
NVIDIA_API_KEY=your_key_here
```

Test:

```txt
create a temp folder with a text file that says "hello world!"
```

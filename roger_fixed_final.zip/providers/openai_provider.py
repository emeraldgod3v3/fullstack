import os
from dotenv import load_dotenv
from openai import AsyncOpenAI

load_dotenv()

class OpenAIProvider:
    name = "openai"

    def __init__(self, model, timeout=45, max_retries=1, streaming=True):
        key = os.getenv("OPENAI_API_KEY", "").strip()
        if not key:
            raise ValueError("OPENAI_API_KEY is missing.")
        self.model = model
        self.timeout = timeout
        self.streaming = streaming
        self.client = AsyncOpenAI(api_key=key, timeout=timeout, max_retries=max_retries)

    async def chat(self, messages, on_token=None, stream=None):
        use_stream = self.streaming if stream is None else stream
        if use_stream:
            stream_obj = await self.client.chat.completions.create(model=self.model, messages=messages, stream=True)
            full = ""
            async for chunk in stream_obj:
                token = chunk.choices[0].delta.content or ""
                full += token
                if token and on_token:
                    on_token(token)
            return full
        response = await self.client.chat.completions.create(model=self.model, messages=messages)
        return response.choices[0].message.content

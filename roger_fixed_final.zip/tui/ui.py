import json
from rich.console import Console
from rich.panel import Panel
from rich.align import Align
from rich.text import Text
from rich.table import Table
from rich.markdown import Markdown
from rich.live import Live
from rich import box
from prompt_toolkit.shortcuts import radiolist_dialog

WOLF = """
 /\\_/\\\\
( ^ᴥ^ )
  🐺
ROGER
"""

class RogerUI:
    def __init__(self):
        self.console = Console()
        self.live = None
        self.stream_buffer = ""

    def show_intro(self):
        title = Text()
        title.append(WOLF, style="bold cyan")
        title.append("\nHappy Wolf AI Agent", style="bold green")
        self.console.print(Panel(Align.center(title), title="[bold cyan]Roger[/bold cyan]", subtitle="Claude-Code-style local tools", border_style="cyan", box=box.ROUNDED))
        self.show_commands()

    def show_commands(self):
        table = Table(title="Quick Commands", box=box.SIMPLE, border_style="green")
        table.add_column("Command", style="cyan", no_wrap=True)
        table.add_column("Action", style="white")
        rows = [("/help", "Commands"), ("/provider", "Provider"), ("/model", "Model"), ("/tools", "Tools"), ("/permissions", "Allowed tools"), ("/clear", "Clear memory"), ("/exit", "Quit")]
        for row in rows:
            table.add_row(*row)
        self.console.print(table)

    def show_ready(self, provider):
        self.console.print(Panel(f"[green]Provider:[/green] {provider.name}\\n[green]Model:[/green] {provider.model}\\n[green]Status:[/green] Ready", title="Session", border_style="green"))

    def thinking(self):
        self.stream_buffer = ""
        self.stop_live()
        self.console.print("[dim cyan]Roger is thinking...[/dim cyan]")

    def stream_token(self, token):
        self.stream_buffer += token
        panel = Panel(Markdown(str(self.stream_buffer)), title="[bold cyan]Roger 🐺 streaming[/bold cyan]", border_style="cyan")
        if self.live is None:
            self.live = Live(panel, console=self.console, refresh_per_second=10, transient=False)
            self.live.start()
        else:
            self.live.update(panel)

    def stop_live(self):
        if self.live:
            self.live.stop()
            self.live = None

    def assistant(self, text, already_streamed=False):
        if self.live:
            self.stop_live()
            if already_streamed:
                return
        self.console.print(Panel(Markdown(str(text)), title="[bold cyan]Roger 🐺[/bold cyan]", border_style="cyan"))

    def ask_tool_permission(self, tool_name, tool_args):
        self.stop_live()
        message = f"Roger wants to run this tool:\\n\\nTool: {tool_name}\\n\\nArguments:\\n{json.dumps(tool_args, indent=2)}\\n\\nUse ↑ ↓ and Enter."
        try:
            result = radiolist_dialog(title="Roger Tool Permission", text=message, values=[("always", f"Always allow {tool_name}"), ("once", f"Allow {tool_name} once"), ("deny", "Don't approve")]).run()
            return result or "deny"
        except Exception:
            self.console.print(Panel(message + "\\n\\nType: always, once, or deny", title="[yellow]Tool Permission[/yellow]", border_style="yellow"))
            while True:
                choice = self.console.input("[yellow]Choice: [/yellow]").strip().lower()
                if choice in ["always", "once", "deny"]:
                    return choice

    def tool_run(self, name, args):
        self.console.print(Panel(json.dumps(args, indent=2), title=f"[magenta]Running tool: {name}[/magenta]", border_style="magenta"))

    def tool_result(self, result):
        self.console.print(Panel(str(result), title="[green]Tool Result[/green]", border_style="green"))

    def warning(self, title, text):
        self.console.print(Panel(str(text), title=title, border_style="yellow"))

    def error(self, title, text):
        self.console.print(Panel(str(text), title=f"[bold red]{title}[/bold red]", border_style="red"))

    def goodbye(self):
        self.stop_live()
        self.console.print("[bold cyan]Roger closed. Goodbye.[/bold cyan]")

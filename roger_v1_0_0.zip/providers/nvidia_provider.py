import json
import os
import httpx
from dotenv import load_dotenv

load_dotenv()

class NvidiaProvider:
    name = "nvidia"

    def __init__(self, model, timeout=25, max_retries=1, streaming=True):
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self.streaming = streaming
        self.base_url = os.getenv(
            "NVIDIA_BASE_URL",
            "https://integrate.api.nvidia.com/v1/chat/completions"
        )
        self.api_key = os.getenv("NVIDIA_API_KEY", "").strip()

        if not self.api_key:
            raise ValueError("NVIDIA_API_KEY is missing. Add it inside .env.")

    async def chat(self, messages, on_token=None, stream=None):
        use_stream = self.streaming if stream is None else stream

        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.3,
            "max_tokens": 512,
            "stream": use_stream,
        }

        if use_stream:
            return await self._stream(payload, on_token)

        return await self._normal(payload)

    async def _normal(self, payload):
        async with httpx.AsyncClient(timeout=self._timeout()) as client:
            response = await client.post(
                self.base_url,
                headers=self._headers(),
                json=payload,
            )

        if response.status_code >= 400:
            return self._err(response.status_code, response.text)

        try:
            return response.json()["choices"][0]["message"]["content"]
        except Exception:
            return "No response received."

    async def _stream(self, payload, on_token):
        full = ""

        try:
            async with httpx.AsyncClient(timeout=self._timeout()) as client:
                async with client.stream(
                    "POST",
                    self.base_url,
                    headers=self._headers(),
                    json=payload,
                ) as response:
                    if response.status_code >= 400:
                        body = await response.aread()

                        return self._err(
                            response.status_code,
                            body.decode(errors="ignore")
                        )

                    async for line in response.aiter_lines():
                        if not line:
                            continue

                        if line.startswith("data: "):
                            line = line[6:]

                        if line.strip() == "[DONE]":
                            break

                        try:
                            data = json.loads(line)
                            choice = data["choices"][0]
                            delta = choice.get("delta", {})
                            token = delta.get("content", "")

                            if not token:
                                token = choice.get("message", {}).get("content", "")

                            if token:
                                full += token

                                if on_token:
                                    on_token(token)

                        except Exception:
                            continue

            return full or await self._normal({**payload, "stream": False})

        except (httpx.ReadTimeout, httpx.ConnectTimeout):
            return "Provider timeout. Try again or switch to a faster model."

        except httpx.RequestError as error:
            return f"Network error: {error}"

    def _headers(self):
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _timeout(self):
        return httpx.Timeout(
            connect=8.0,
            read=self.timeout,
            write=8.0,
            pool=8.0,
        )

    def _err(self, status, body):
        if status == 401:
            return "NVIDIA API error 401. Check your NVIDIA_API_KEY."

        if status == 404:
            return f"NVIDIA API error 404. Check model name: {self.model}"

        if status == 429:
            return "NVIDIA API error 429. Rate limit reached."

        return f"NVIDIA API error {status}: {body[:300]}"

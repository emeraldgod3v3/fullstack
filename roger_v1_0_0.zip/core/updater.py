import os
import shutil
import tempfile
import zipfile
from pathlib import Path

import httpx

from core.version import get_project_version

class RogerUpdater:
    def __init__(self, ui):
        self.ui = ui
        self.update_url = os.getenv("ROGER_UPDATE_URL", "").strip()

    async def run(self):
        current = get_project_version()
        self.ui.info("Updater", f"Current version: {current}")

        if not self.update_url:
            self.ui.warning(
                "No update URL",
                "Set ROGER_UPDATE_URL in .env to your GitHub release zip URL or raw zip URL."
            )
            self.ui.info(
                "How to use",
                "After pushing a new zip release, set ROGER_UPDATE_URL and run:\npython3 main.py --update"
            )
            return

        try:
            with tempfile.TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                zip_path = tmp_path / "roger_update.zip"

                self.ui.info("Updater", "Downloading update package...")

                async with httpx.AsyncClient(timeout=60) as client:
                    response = await client.get(self.update_url)

                if response.status_code >= 400:
                    self.ui.error("Update failed", f"Download failed: HTTP {response.status_code}")
                    return

                zip_path.write_bytes(response.content)

                extract_dir = tmp_path / "extract"
                extract_dir.mkdir()

                with zipfile.ZipFile(zip_path, "r") as z:
                    z.extractall(extract_dir)

                candidate = self._find_project_root(extract_dir)
                new_version = get_project_version(candidate / "CHANGELOGS.md")

                self.ui.info("Updater", f"Available version: {new_version}")

                if new_version == current:
                    self.ui.info("Updater", "Already up to date.")
                    return

                self._copy_update(candidate, Path.cwd())

                self.ui.info(
                    "Update complete",
                    "Roger source was updated. Run this command again if another update exists:\npython3 main.py --update"
                )

        except Exception as error:
            self.ui.error("Update failed", str(error))

    def _find_project_root(self, extract_dir):
        if (extract_dir / "CHANGELOGS.md").exists():
            return extract_dir

        for item in extract_dir.iterdir():
            if item.is_dir() and (item / "CHANGELOGS.md").exists():
                return item

        return extract_dir

    def _copy_update(self, src, dst):
        skip = {
            ".env",
            ".roger_permissions.json",
            "WOLF.md",
            "workspace",
            "venv",
            "__pycache__",
            ".git",
        }

        for item in src.iterdir():
            if item.name in skip:
                continue

            target = dst / item.name

            if item.is_dir():
                if target.exists():
                    shutil.rmtree(target)
                shutil.copytree(item, target)
            else:
                shutil.copy2(item, target)

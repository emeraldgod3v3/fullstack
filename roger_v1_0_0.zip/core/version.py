from pathlib import Path

def get_project_version(path="CHANGELOGS.md"):
    file = Path(path)

    if not file.exists():
        return "0.0.0"

    for line in file.read_text(encoding="utf-8").splitlines():
        if line.startswith("project-version:"):
            return line.split(":", 1)[1].strip()

    return "0.0.0"

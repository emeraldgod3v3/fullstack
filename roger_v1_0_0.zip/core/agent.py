import asyncio
from pathlib import Path

from commands.parser import SlashParser
from tools.registry import ToolRegistry
from core.permissions import PermissionManager
from core.action_engine import ActionEngine
from core.memory import WolfMemory

def load_roger_prompt():
    path = Path("ROGER.md")

    if path.exists():
        return path.read_text(encoding="utf-8")

    return "You are Roger, a CLI AI agent."

class RogerAgent:
    def __init__(self, provider, ui):
        self.provider = provider
        self.ui = ui
        self.parser = SlashParser()
        self.tools = ToolRegistry()
        self.permissions = PermissionManager()
        self.action_engine = ActionEngine()
        self.memory = WolfMemory()
        self.messages = []
        self._refresh_system_prompt()

    async def run(self, prompt):
        command = self.parser.parse(prompt)

        if command:
            self.ui.assistant(self.handle_command(command))
            return

        memory = self.memory.detect_memory(prompt)

        if memory:
            result = self.memory.remember(memory)
            self.ui.assistant(result)
            self._refresh_system_prompt()
            return

        self.messages.append({"role": "user", "content": prompt})

        actions = self.action_engine.plan(prompt)

        if actions:
            await self._run_actions(actions)
            return

        await self._chat(prompt)

    async def _chat(self, prompt):
        self.ui.thinking()

        try:
            response = await asyncio.wait_for(
                self.provider.chat(
                    self.messages,
                    self.ui.stream_token,
                    stream=True
                ),
                timeout=self.provider.timeout + 5
            )

        except asyncio.TimeoutError:
            self.ui.error(
                "Provider timeout",
                "The model took too long. Try again or switch to a faster model."
            )
            return

        if not response or response.strip() in ["", "No response received."]:
            response = self._fallback_response(prompt)

        self.messages.append({"role": "assistant", "content": response})
        self.ui.assistant(response, already_streamed=True)

    async def _run_actions(self, actions):
        for action in actions:
            name = action["name"]
            args = action["arguments"]

            if not await self._approve(name, args):
                self.ui.assistant(f"Tool request denied: {name}. Request ended.")
                return

            self.ui.tool_run(name, args)
            result = await self.tools.run(name, args)
            self.ui.tool_result(result)

        final = self._action_final(actions)

        self.messages.append({"role": "assistant", "content": final})
        self.ui.assistant(final)

    def _action_final(self, actions):
        names = [action["name"] for action in actions]

        if "terminal" in names:
            return "Done. I ran the approved shell command and showed the result above."

        if "create_folder" in names and "write_file" in names:
            return "Done. I created the folder and file inside the workspace."

        if "write_file" in names:
            return "Done. I created the file inside the workspace."

        if "create_folder" in names:
            return "Done. I created the folder inside the workspace."

        return "Done. The requested action finished."

    async def _approve(self, name, args):
        if self.permissions.is_always_allowed(name):
            return True

        choice = self.ui.ask_tool_permission(name, args)

        if choice == "always":
            self.permissions.allow_always(name)
            return True

        return choice == "once"

    def _refresh_system_prompt(self):
        self.messages = [
            {
                "role": "system",
                "content": load_roger_prompt() + "\n\nUser memory:\n" + self.memory.read()
            }
        ]

    def _fallback_response(self, prompt):
        lower = prompt.lower()

        if "hi" in lower or "hello" in lower:
            return "Hello. I am Roger. How can I help you today?"

        if "who are you" in lower:
            return "I am Roger, a CLI AI agent for terminal work, coding, files, memory, and project automation."

        return "I did not receive a provider response, but I am still running. Try asking again, or use a tool command like `ls`, `pwd`, or `show project files`."

    def handle_command(self, command):
        cmd = command["command"]

        if cmd == "/help":
            return "/help\n/about\n/provider\n/model\n/tools\n/permissions\n/memory\n/update\n/clear\n/exit"

        if cmd == "/about":
            return "ROGER v1.0.0 uses ROGER.md for role, WOLF.md for memory, and CHANGELOGS.md for updates."

        if cmd == "/provider":
            return f"Provider: {self.provider.name}"

        if cmd == "/model":
            return f"Model: {self.provider.model}"

        if cmd == "/tools":
            return "\n".join(self.tools.list_tools())

        if cmd == "/permissions":
            allowed = self.permissions.list_allowed()
            return "\n".join(allowed) if allowed else "No tools are always allowed."

        if cmd == "/memory":
            return self.memory.read()

        if cmd == "/update":
            return "Run this in your terminal: python3 main.py --update"

        if cmd == "/clear":
            self._refresh_system_prompt()
            return "Chat memory cleared."

        return f"Unknown command: {cmd}"

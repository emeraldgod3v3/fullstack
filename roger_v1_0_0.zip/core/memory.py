from pathlib import Path
from datetime import datetime

class WolfMemory:
    def __init__(self, path="WOLF.md"):
        self.path = Path(path)

        if not self.path.exists():
            self.path.write_text("# WOLF Memory\n\n## Memories\n\n- No memories yet.\n")

    def read(self):
        return self.path.read_text(encoding="utf-8")

    def remember(self, memory):
        content = self.read()

        if "- No memories yet." in content:
            content = content.replace("- No memories yet.", "")

        stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        line = f"- [{stamp}] {memory}\n"

        content = content.rstrip() + "\n" + line

        self.path.write_text(content, encoding="utf-8")

        return f"Saved memory: {memory}"

    def detect_memory(self, prompt):
        lower = prompt.lower().strip()

        triggers = [
            "remember that ",
            "remember ",
            "take note that ",
            "note that ",
            "i like ",
            "i prefer ",
            "my name is ",
            "from now on ",
        ]

        for trigger in triggers:
            if trigger in lower:
                index = lower.find(trigger)
                value = prompt[index + len(trigger):].strip()

                if trigger == "i like ":
                    return f"User likes {value}"

                if trigger == "i prefer ":
                    return f"User prefers {value}"

                if trigger == "my name is ":
                    return f"User's name is {value}"

                return value

        return None

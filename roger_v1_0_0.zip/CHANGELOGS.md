project-version: 1.0.0
project-date: 2026.5.9

# Changelogs

## 1.0.0

- Added modern TUI shell
- Added bordered input prompt
- Added local action engine
- Added shell intent handling
- Added updater command
- Added `python3 main.py --update`
- Added `ROGER.md`
- Added `WOLF.md`
- Added memory system
- Added safer provider fallback responses
- Fixed blank model responses

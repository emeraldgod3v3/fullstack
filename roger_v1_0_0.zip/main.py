import asyncio
import os
import sys
from dotenv import load_dotenv
from prompt_toolkit import PromptSession
from prompt_toolkit.styles import Style

from core.agent import RogerAgent
from core.provider_loader import load_provider
from core.updater import RogerUpdater
from tui.ui import RogerUI

load_dotenv()

def clear_terminal():
    if os.getenv("CLEAR_ON_START", "true").lower() == "true":
        os.system("cls" if os.name == "nt" else "clear")

async def app():
    if "--update" in sys.argv:
        ui = RogerUI()
        updater = RogerUpdater(ui)
        await updater.run()
        return

    clear_terminal()

    ui = RogerUI()
    ui.show_intro()

    try:
        provider = load_provider()
    except Exception as error:
        ui.error("Startup failed", str(error))
        return

    agent = RogerAgent(provider, ui)
    session = PromptSession(
        style=Style.from_dict({
            "prompt": "ansicyan bold"
        })
    )

    ui.show_ready(provider)

    while True:
        try:
            ui.start_prompt_panel()
            text = (await session.prompt_async([("class:prompt", "│  ")]))
            ui.end_prompt_panel()

            text = text.strip()

            if not text:
                continue

            if text == "/exit":
                ui.goodbye()
                break

            await agent.run(text)

        except KeyboardInterrupt:
            ui.end_prompt_panel()
            ui.warning("Input cancelled", "Press /exit to close Roger.")
        except EOFError:
            ui.end_prompt_panel()
            ui.goodbye()
            break
        except Exception as error:
            ui.end_prompt_panel()
            ui.error("Unexpected error", str(error))

if __name__ == "__main__":
    asyncio.run(app())

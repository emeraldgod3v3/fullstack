# ROGER v1.0.0

## New

- Better prompt input border
- Modern TUI
- `python3 main.py --update`
- `CHANGELOGS.md`
- `project-version: 1.0.0`
- safer blank response fallback
- better shell intent routing
- `ROGER.md`
- `WOLF.md`

## Copy-paste install

```bash
rm -rf roger && unzip roger_v1_0_0.zip -d roger && cd roger && python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt && cp .env.example .env && nano .env && python3 main.py
```

Add:

```env
NVIDIA_API_KEY=your_key_here
```

## Update command

Set this in `.env`:

```env
ROGER_UPDATE_URL=https://your-github-release-or-raw-zip-url.zip
```

Then run:

```bash
python3 main.py --update
```

The updater keeps:

- `.env`
- `WOLF.md`
- `.roger_permissions.json`
- `workspace/`
- `venv/`

## Test commands

```txt
show me the whole project folder content
```

```txt
i like coffee
```

```txt
/memory
```

import asyncio
from rich.console import Console
from core.agent import RogerAgent
from providers.openai_provider import OpenAIProvider

console = Console()

async def main():
    provider = OpenAIProvider(
        model="gpt-4.1"
    )

    agent = RogerAgent(provider)

    console.print("[bold cyan]Roger CLI Started[/bold cyan]")

    while True:
        user_input = input("Roger > ")

        if user_input.strip() == "/exit":
            break

        response = await agent.run(user_input)

        console.print(f"\n[green]{response}[/green]\n")

if __name__ == "__main__":
    asyncio.run(main())

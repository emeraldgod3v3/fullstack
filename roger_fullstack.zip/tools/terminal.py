import subprocess

SAFE_COMMANDS = [
    "ls",
    "pwd",
    "echo",
    "cat",
    "python",
    "pip"
]

async def terminal_tool(command):
    base = command.split()[0]

    if base not in SAFE_COMMANDS:
        return "Blocked command"

    result = subprocess.run(
        command,
        shell=True,
        capture_output=True,
        text=True
    )

    return result.stdout

from tools.registry import ToolRegistry
from commands.parser import SlashParser

class RogerAgent:
    def __init__(self, provider):
        self.provider = provider
        self.tools = ToolRegistry()
        self.parser = SlashParser()

    async def run(self, prompt):
        command = self.parser.parse(prompt)

        if command:
            return self.handle_command(command)

        messages = [
            {
                "role": "user",
                "content": prompt
            }
        ]

        response = await self.provider.chat(messages)

        return response

    def handle_command(self, command):
        cmd = command["command"]

        if cmd == "/help":
            return '''
Available Commands:
- /help
- /exit
- /tools
- /agents
- /create-agent
- /load-agent
'''

        if cmd == "/tools":
            return str(self.tools.list_tools())

        return f"Unknown command: {cmd}"

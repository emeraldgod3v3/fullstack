# Roger

Roger is a CLI AI agent inspired by Claude Code.

## Features

- Interactive CLI
- Tool calling
- Terminal execution
- Slash commands
- Multi-provider support
- Sub-agents
- Persistent memory
- Streaming responses

## Supported Providers

- OpenAI
- Anthropic
- NVIDIA NIM
- OpenRouter

## Setup

### 1. Install Python

Use Python 3.12+

### 2. Create Virtual Environment

```bash
python -m venv venv
```

Linux/macOS:

```bash
source venv/bin/activate
```

Windows:

```powershell
venv\Scripts\activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure Environment

Rename `.env.example` to `.env`

Add your API keys.

### 5. Run Roger

```bash
python main.py
```

## Commands

```txt
/help
/exit
/tools
/agents
/create-agent
/load-agent
```

## Example

```txt
Roger > create a python calculator
```

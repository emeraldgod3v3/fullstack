import os
from dotenv import load_dotenv
from anthropic import AsyncAnthropic

load_dotenv()

class AnthropicProvider:
    def __init__(self, model):
        self.model = model
        self.client = AsyncAnthropic(
            api_key=os.getenv("ANTHROPIC_API_KEY")
        )

    async def chat(self, messages):
        response = await self.client.messages.create(
            model=self.model,
            max_tokens=2048,
            messages=messages
        )

        return response.content[0].text

import os
from dotenv import load_dotenv
from openai import AsyncOpenAI

load_dotenv()

class OpenAIProvider:
    def __init__(self, model):
        self.model = model
        self.client = AsyncOpenAI(
            api_key=os.getenv("OPENAI_API_KEY")
        )

    async def chat(self, messages):
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=messages
        )

        return response.choices[0].message.content
